import os
import pandas as pd
import time
from dotenv import load_dotenv
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.header import Header

def detect_unauthorized_access(csv_file, alert_window_minutes=None, fail_threshold=None, debounce_file=".alert_debounce"):
    # Allow thresholds to be set via environment variables for flexibility
    if alert_window_minutes is None:
        alert_window_minutes = int(os.environ.get('ALERT_WINDOW_MINUTES', 5))
    if fail_threshold is None:
        fail_threshold = int(os.environ.get('ALERT_FAIL_THRESHOLD', 5))
    # Load the CSV file (expecting columns: EventID, TimeCreated, TargetUserName, IpAddress/WorkstationName)
    df = pd.read_csv(csv_file)
    if 'EventID' not in df.columns:
        print("EventID column not found in CSV.")
        return
    # Filter for Event ID 4625 (failed logon)
    failed_logons = df[df['EventID'] == 4625]
    if failed_logons.empty:
        print("No failed logon attempts detected.")
        return
    # Convert time column to datetime
    time_col = None
    for col in ['TimeCreated', 'Timestamp', 'time', 'Date', 'Datetime']:
        if col in failed_logons.columns:
            time_col = col
            failed_logons[col] = pd.to_datetime(failed_logons[col], errors='coerce')
            break
    if not time_col:
        print("No recognizable time column found.")
        return
    # Only consider recent entries (last alert_window_minutes)
    now = pd.Timestamp.now()
    window_start = now - pd.Timedelta(minutes=alert_window_minutes)
    recent = failed_logons[failed_logons[time_col] >= window_start]
    # Group by user and source, count attempts
    group_cols = ['TargetUserName']
    for extra in ['IpAddress', 'WorkstationName', 'Source', 'ComputerName']:
        if extra in recent.columns:
            group_cols.append(extra)
            break
    agg = recent.groupby(group_cols).size().reset_index(name='FailedAttempts')
    # Debounce: Only alert once per user/source per window
    alerted = set()
    if os.path.exists(debounce_file):
        with open(debounce_file, 'r') as f:
            for line in f:
                alerted.add(line.strip())
    alerts_to_send = []
    for _, row in agg.iterrows():
        if row['FailedAttempts'] >= fail_threshold:
            alert_id = '|'.join(str(row[col]) for col in group_cols)
            if alert_id not in alerted:
                alerts_to_send.append(row)
                alerted.add(alert_id)
    if not alerts_to_send:
        print("No new alert-worthy failed logon patterns detected.")
        return
    # Send alert email for each
    load_dotenv()
    recipient = os.environ.get('RECIPIENT_EMAIL', 'recipient@example.com')
    for row in alerts_to_send:
        user = row['TargetUserName']
        attempts = row['FailedAttempts']
        source = None
        for extra in ['IpAddress', 'WorkstationName', 'Source', 'ComputerName']:
            if extra in row:
                source = row[extra]
                break
        last_time = recent[(recent['TargetUserName']==user) & ((recent[group_cols[1]]==source) if source else True)][time_col].max()
        subject = "\ud83d\udea8 SECURITY ALERT: Unauthorized Logon Attempt Detected on Your Windows System"
        body = f"""
🚨 SECURITY ALERT: Unauthorized Logon Attempt Detected

Someone attempted to access your system using invalid credentials.

Details:
    • User: {user}
    • Time: {last_time}
    • Attempts: {attempts} failed logins
    • Source: {source if source else 'Unknown'}

If this was not you, please take immediate action to secure your machine.

-- Hayabusa Automated Security Monitor
"""
        # Save alert to debounce file
        with open(debounce_file, 'a') as f:
            f.write('|'.join(str(row[col]) for col in group_cols) + '\n')
        # Send real email alert
        try:
            sender_email = os.environ.get('EMAIL_USERNAME', '')
            sender_password = os.environ.get('EMAIL_PASSWORD', '')
            msg = MIMEMultipart()
            msg['From'] = sender_email
            msg['To'] = recipient
            msg['Subject'] = Header(subject, 'utf-8')
            msg.attach(MIMEText(body, 'plain', 'utf-8'))
            # Attach the latest PDF report from data/reports/
            try:
                pdf_files = glob.glob('data/reports/*.pdf')
                if pdf_files:
                    latest_pdf = max(pdf_files, key=os.path.getmtime)
                    with open(latest_pdf, 'rb') as f:
                        pdf_attachment = MIMEApplication(f.read(), _subtype="pdf")
                        pdf_attachment.add_header('Content-Disposition', 'attachment', filename=os.path.basename(latest_pdf))
                        msg.attach(pdf_attachment)
            except Exception as pdf_e:
                print(f"[ATTACHMENT ERROR] Could not attach PDF report: {pdf_e}")
            with smtplib.SMTP_SSL('smtp.gmail.com', 465) as server:
                server.login(sender_email, sender_password)
                server.send_message(msg)
            print(f"[EMAIL SENT] {subject}\n{body}")
        except Exception as e:
            print(f"[EMAIL ERROR] Could not send alert email: {e}\n{subject}\n{body}")

if __name__ == "__main__":
    load_dotenv()
    # Allow monitored files to be set via environment variable or default list
    monitored_files = os.environ.get('ALERT_MONITOR_FILES')
    if monitored_files:
        monitored_files = [f.strip() for f in monitored_files.split(',')]
    else:
        monitored_files = [
            "data/uploads/test.csv",
            "data/uploads/timeline.csv"
        ]
    print(f"Monitoring files: {monitored_files}")
    while True:
        for file in monitored_files:
            if os.path.exists(file):
                # Send monitoring started email with PDF attachment
                try:
                    sender_email = os.environ.get('EMAIL_USERNAME', '')
                    sender_password = os.environ.get('EMAIL_PASSWORD', '')
                    recipient = os.environ.get('RECIPIENT_EMAIL', 'recipient@example.com')
                    subject = "\U0001F7E2 Monitoring Started: File Received for Security Check"
                    body = f"The file {os.path.basename(file)} has been received and is being analyzed for security threats."
                    msg = MIMEMultipart()
                    msg['From'] = sender_email
                    msg['To'] = recipient
                    msg['Subject'] = Header(subject, 'utf-8')
                    msg.attach(MIMEText(body, 'plain', 'utf-8'))
                    import glob
                    pdf_files = glob.glob('data/reports/*.pdf')
                    if pdf_files:
                        latest_pdf = max(pdf_files, key=os.path.getmtime)
                        from email.mime.application import MIMEApplication
                        with open(latest_pdf, 'rb') as f_pdf:
                            pdf_attachment = MIMEApplication(f_pdf.read(), _subtype="pdf")
                            pdf_attachment.add_header('Content-Disposition', 'attachment', filename=os.path.basename(latest_pdf))
                            msg.attach(pdf_attachment)
                    with smtplib.SMTP_SSL('smtp.gmail.com', 465) as server:
                        server.login(sender_email, sender_password)
                        server.send_message(msg)
                    print(f"[EMAIL SENT] {subject}\n{body}")
                except Exception as e:
                    print(f"[EMAIL ERROR] Could not send monitoring started email: {e}")
                detect_unauthorized_access(file)
        time.sleep(60)
