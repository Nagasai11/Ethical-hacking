import os
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import random
import argparse

def generate_simulated_data(output_file, num_events=1000, days=7):
    """
    Generate simulated Windows Event Log data for testing
    
    Args:
        output_file (str): Path to save the CSV file
        num_events (int): Number of events to generate
        days (int): Number of days to spread events across
    """
    print(f"Generating {num_events} simulated events across {days} days...")
    
    # Create a date range for the specified number of days
    end_date = datetime.now()
    start_date = end_date - timedelta(days=days)
    
    # Event IDs commonly found in Windows logs with descriptions
    event_ids_with_desc = {
        4624: "An account was successfully logged on",
        4625: "An account failed to log on",
        4634: "An account was logged off",
        4648: "A logon was attempted using explicit credentials",
        4672: "Special privileges assigned to new logon",
        4688: "A new process has been created",
        4720: "A user account was created",
        4724: "An attempt was made to reset an account's password",
        4728: "A member was added to a security-enabled global group",
        5140: "A network share object was accessed",
        7045: "A service was installed in the system"
    }
    
    # Severity levels with weights (probability)
    severity_levels = ['high', 'medium', 'low']
    severity_weights = [0.2, 0.3, 0.5]  # 20% high, 30% medium, 50% low
    
    # Computer names
    computer_names = [
        "DESKTOP-SERVER1", "DESKTOP-SERVER2", "DESKTOP-WORKSTATION1", 
        "DESKTOP-WORKSTATION2", "LAPTOP-USER1", "LAPTOP-USER2"
    ]
    
    # Channels
    channels = ["Security", "System", "Application"]
    
    # Generate random timestamps within the date range
    timestamps = [
        start_date + timedelta(
            seconds=random.randint(0, int((end_date - start_date).total_seconds()))
        ) for _ in range(num_events)
    ]
    timestamps.sort()  # Sort chronologically
    
    # Generate random data
    data = {
        'Timestamp': [d.strftime("%Y-%m-%d %H:%M:%S") for d in timestamps],
        'EventID': [random.choice(list(event_ids_with_desc.keys())) for _ in range(num_events)],
        'Computer': [random.choice(computer_names) for _ in range(num_events)],
        'Channel': [random.choice(channels) for _ in range(num_events)],
        'Level': np.random.choice(severity_levels, size=num_events, p=severity_weights),
    }
    
    # Add descriptions based on Event IDs
    data['Description'] = [event_ids_with_desc[event_id] for event_id in data['EventID']]
    
    # Create DataFrame
    df = pd.DataFrame(data)
    
    # Add some specific high-severity events to make the data more interesting
    high_events = [
        {'Timestamp': (end_date - timedelta(hours=12)).strftime("%Y-%m-%d %H:%M:%S"), 
         'EventID': 4625, 
         'Computer': 'DESKTOP-SERVER1', 
         'Channel': 'Security', 
         'Level': 'high', 
         'Description': 'Failed login attempt from suspicious IP 192.168.1.100'},
        {'Timestamp': (end_date - timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S"), 
         'EventID': 4672, 
         'Computer': 'DESKTOP-SERVER1', 
         'Channel': 'Security', 
         'Level': 'high', 
         'Description': 'Special privileges assigned to new logon - Admin account'},
        {'Timestamp': (end_date - timedelta(hours=4)).strftime("%Y-%m-%d %H:%M:%S"), 
         'EventID': 7045, 
         'Computer': 'DESKTOP-SERVER1', 
         'Channel': 'System', 
         'Level': 'high', 
         'Description': 'New service was installed: suspicious.exe'},
        {'Timestamp': (end_date - timedelta(hours=2)).strftime("%Y-%m-%d %H:%M:%S"), 
         'EventID': 4720, 
         'Computer': 'DESKTOP-SERVER2', 
         'Channel': 'Security', 
         'Level': 'high', 
         'Description': 'A user account was created with admin privileges'},
        {'Timestamp': (end_date - timedelta(hours=1)).strftime("%Y-%m-%d %H:%M:%S"), 
         'EventID': 4688, 
         'Computer': 'LAPTOP-USER1', 
         'Channel': 'Security', 
         'Level': 'high', 
         'Description': 'A new process has been created: cmd.exe with suspicious arguments'}
    ]
    
    # Append high severity events
    for event in high_events:
        df = pd.concat([df, pd.DataFrame([event])], ignore_index=True)
    
    # Sort by timestamp
    df['Timestamp'] = pd.to_datetime(df['Timestamp'])
    df = df.sort_values('Timestamp').reset_index(drop=True)
    
    # Save to CSV
    os.makedirs(os.path.dirname(output_file), exist_ok=True)
    df.to_csv(output_file, index=False)
    
    print(f"Generated {len(df)} events and saved to {output_file}")
    print(f"Severity distribution: {df['Level'].value_counts().to_dict()}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate simulated Windows Event Log data")
    parser.add_argument("--output", default="data/uploads/simulated_events.csv", help="Output CSV file path")
    parser.add_argument("--events", type=int, default=1000, help="Number of events to generate")
    parser.add_argument("--days", type=int, default=7, help="Number of days to spread events across")
    
    args = parser.parse_args()
    generate_simulated_data(args.output, args.events, args.days)
