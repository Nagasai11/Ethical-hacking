import os
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import dash
from dash import dcc, html
from dash.dependencies import Input, Output
import argparse

def generate_test_dashboard(csv_file, output_dir="data/reports"):
    """
    Generate a test dashboard using the provided CSV file
    
    Args:
        csv_file (str): Path to the CSV file
        output_dir (str): Directory to save the output files
    """
    print(f"Generating test dashboard using {csv_file}...")
    
    # Create output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)
    
    # Read the CSV file
    df = pd.read_csv(csv_file)
    
    # Convert timestamp to datetime
    df['Timestamp'] = pd.to_datetime(df['Timestamp'])
    
    # Create a simple HTML dashboard
    html_content = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Automated Threat Analysis Dashboard</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
        <style>
            body {
                font-family: Arial, sans-serif;
                margin: 0;
                padding: 20px;
                background-color: #f5f5f5;
            }
            .container {
                max-width: 1200px;
                margin: 0 auto;
                background-color: white;
                padding: 20px;
                box-shadow: 0 0 10px rgba(0,0,0,0.1);
            }
            .header {
                text-align: center;
                margin-bottom: 30px;
            }
            .chart-container {
                margin-bottom: 30px;
                padding: 15px;
                background-color: white;
                border-radius: 5px;
                box-shadow: 0 0 5px rgba(0,0,0,0.1);
            }
            .summary {
                margin-bottom: 20px;
                padding: 15px;
                background-color: #f9f9f9;
                border-left: 4px solid #007bff;
            }
            table {
                width: 100%;
                border-collapse: collapse;
                margin-bottom: 20px;
            }
            th, td {
                padding: 12px;
                text-align: left;
                border-bottom: 1px solid #ddd;
            }
            th {
                background-color: #f2f2f2;
            }
            tr:hover {
                background-color: #f5f5f5;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>Automated Threat Analysis Dashboard</h1>
                <p>Generated on {timestamp}</p>
            </div>
            
            <div class="summary">
                <h2>Analysis Summary</h2>
                <p>Total events analyzed: {total_events}</p>
                <p>Time range: {time_range}</p>
                <p>Severity distribution: {severity_distribution}</p>
            </div>
            
            <div class="chart-container">
                <h2>Event Timeline</h2>
                <div id="timeline-chart"></div>
            </div>
            
            <div class="chart-container">
                <h2>Severity Distribution</h2>
                <div id="severity-chart"></div>
            </div>
            
            <div class="chart-container">
                <h2>Top Event IDs</h2>
                <div id="eventid-chart"></div>
            </div>
            
            <div class="chart-container">
                <h2>Top 10 High Severity Events</h2>
                <table id="high-severity-table">
                    <tr>
                        <th>Timestamp</th>
                        <th>Event ID</th>
                        <th>Description</th>
                        <th>Computer</th>
                        <th>Severity</th>
                    </tr>
                    {high_severity_rows}
                </table>
            </div>
        </div>
        
        <script>
            {plotly_scripts}
        </script>
    </body>
    </html>
    """
    
    # Generate timeline chart
    events_per_hour = df.groupby(pd.Grouper(key='Timestamp', freq='1H')).size().reset_index(name='count')
    fig_timeline = px.line(events_per_hour, x='Timestamp', y='count', 
                          title='Events Over Time',
                          labels={'count': 'Number of Events', 'Timestamp': 'Time'})
    
    # Generate severity distribution chart
    severity_counts = df['Level'].value_counts().reset_index()
    severity_counts.columns = ['Level', 'Count']
    fig_severity = px.pie(severity_counts, values='Count', names='Level', 
                         title='Event Severity Distribution',
                         color_discrete_map={'high': 'red', 'medium': 'orange', 'low': 'blue', 'info': 'green'})
    
    # Generate event ID chart
    eventid_counts = df['EventID'].value_counts().head(10).reset_index()
    eventid_counts.columns = ['EventID', 'Count']
    fig_eventid = px.bar(eventid_counts, x='EventID', y='Count', 
                        title='Top 10 Event IDs',
                        labels={'Count': 'Number of Events', 'EventID': 'Event ID'})
    
    # Generate high severity table rows
    high_severity_df = df[df['Level'].isin(['high', 'medium'])].sort_values('Timestamp', ascending=False).head(10)
    if len(high_severity_df) == 0:  # If no high/medium events, just take the top 10
        high_severity_df = df.sort_values('Timestamp', ascending=False).head(10)
    
    high_severity_rows = ""
    for _, row in high_severity_df.iterrows():
        description = row.get('RuleTitle', '') if 'RuleTitle' in row else row.get('Details', '')
        high_severity_rows += f"""
        <tr>
            <td>{row['Timestamp']}</td>
            <td>{row['EventID']}</td>
            <td>{description}</td>
            <td>{row['Computer']}</td>
            <td>{row['Level']}</td>
        </tr>
        """
    
    # Generate plotly scripts
    plotly_scripts = f"""
    var timelineData = {fig_timeline.to_json()};
    Plotly.newPlot('timeline-chart', timelineData.data, timelineData.layout);
    
    var severityData = {fig_severity.to_json()};
    Plotly.newPlot('severity-chart', severityData.data, severityData.layout);
    
    var eventidData = {fig_eventid.to_json()};
    Plotly.newPlot('eventid-chart', eventidData.data, eventidData.layout);
    """
    
    # Fill in the template
    html_content = html_content.format(
        timestamp=pd.Timestamp.now().strftime("%Y-%m-%d %H:%M:%S"),
        total_events=len(df),
        time_range=f"{df['Timestamp'].min()} to {df['Timestamp'].max()}",
        severity_distribution=dict(df['Level'].value_counts()),
        high_severity_rows=high_severity_rows,
        plotly_scripts=plotly_scripts
    )
    
    # Write the HTML file
    output_file = os.path.join(output_dir, "test_dashboard.html")
    with open(output_file, "w") as f:
        f.write(html_content)
    
    print(f"Dashboard generated: {output_file}")
    return output_file

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate a test dashboard using a CSV file")
    parser.add_argument("--file", default="data/uploads/timeline.csv", help="Path to the CSV file")
    parser.add_argument("--output", default="data/reports", help="Directory to save the output files")
    
    args = parser.parse_args()
    dashboard_file = generate_test_dashboard(args.file, args.output)
    
    # Try to open the dashboard in the default browser
    try:
        import webbrowser
        print(f"Opening dashboard in browser: {dashboard_file}")
        webbrowser.open(f"file://{os.path.abspath(dashboard_file)}")
    except Exception as e:
        print(f"Could not open dashboard in browser: {str(e)}")
        print(f"Please open the dashboard manually: {dashboard_file}")
