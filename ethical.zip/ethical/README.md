# Automated Threat Analysis and Visualization Tool

## Overview

The Automated Threat Analysis and Visualization Tool is a comprehensive solution for analyzing Windows Event Logs (.evtx files) to detect, visualize, and report on potential security threats. This tool integrates with Hayabusa for log parsing and provides a user-friendly web interface for data visualization and analysis.

![Dashboard Example](data/reports/dashboard_example.png)

## Features

- **Log Parsing**: Integrates with Hayabusa to parse Windows Event Logs (.evtx files)
- **Data Analysis**: Analyzes logs to extract high-risk threat patterns and categorize events by severity
- **Visualization**: Creates interactive dashboards to visualize event timelines, severity distributions, and critical events
- **PDF Reporting**: Generates professional PDF reports summarizing the analysis
- **Email Notifications**: Sends alerts via email when high-severity events are detected
- **Scheduling**: Automates periodic analysis of log files

## Tech Stack

- **Log Parsing**: Hayabusa
- **Backend Processing**: Python, pandas
- **Web Framework**: Flask, Dash
- **Visualization**: Plotly, Matplotlib
- **PDF Generation**: ReportLab
- **Email Notifications**: Flask-Mail / smtplib
- **Scheduler**: schedule module

## Installation

### Prerequisites

- Python 3.8 or higher
- Hayabusa (for production use)

### Setup

1. Clone the repository:
   ```
   git clone https://github.com/yourusername/automated-threat-analysis.git
   cd automated-threat-analysis
   ```

2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
   Or use the provided batch file:
   ```
   install.bat
   ```

3. Configure the application:
   - Edit `config.py` to set your email settings and Hayabusa paths
   - Create necessary directories: `data/uploads` and `data/reports`

4. (Optional) Install Hayabusa:
   - Follow the instructions in the [Hayabusa GitHub repository](https://github.com/Yamato-Security/hayabusa)
   - Update the Hayabusa path in `config.py`

## Usage

### Quick Start

1. Run the web application:
   ```
   python start_app.py
   ```
   Or use the provided batch file:
   ```
   start_webapp.bat
   ```

2. Open your browser and navigate to `http://127.0.0.1:8050`

3. Upload a Windows Event Log (.evtx) file or use the timeline.csv file for analysis

### Demo Mode

To run a demonstration of the full analysis pipeline:

```
python demo.py
```

Or use the provided batch file:
```
run_demo.bat
```

### Batch Processing

To run the analysis pipeline without the web interface:

```
python run_pipeline.py --file path/to/your/evtx/file.evtx
```

Or use the provided batch file:
```
run_pipeline.bat
```

### Generate Reports

To generate a PDF report from a parsed log file:

```
python generate_pdf_report.py --file data/uploads/timeline.csv
```

Or use the provided batch file:
```
generate_pdf_report.bat
```

### Generate Dashboard

To generate an HTML dashboard from a parsed log file:

```
python simple_dashboard.py --file data/uploads/timeline.csv
```

Or use the provided batch file:
```
run_simple_dashboard.bat
```

## How It Works

1. **Log Extraction**: Hayabusa scans `.evtx` files using Sigma rules and generates a structured `.csv` timeline of detected events.
2. **Data Processing**: The CSV is cleaned and filtered using `pandas`. Events are classified based on severity levels (High, Medium, Low).
3. **Visualization Dashboard**: A responsive web dashboard built using Dash displays time-series plots, severity distribution, and critical event listings.
4. **PDF Report Generation**: A neatly formatted report is created with event summaries and critical alerts using `reportlab`.
5. **Email Dispatch**: The report is automatically sent to administrators via SMTP.
6. **Real-Time Monitoring**: A scheduler script runs the process at defined intervals for continuous monitoring.

## Project Structure

```
automated-threat-analysis/
├── app.py                      # Main Flask/Dash application
├── config.py                   # Configuration settings
├── requirements.txt            # Python dependencies
├── setup.py                    # Setup script for dependencies
├── run_pipeline.py             # Script to run the full analysis pipeline
├── start_app.py                # Script to start the web application
├── demo.py                     # Demonstration script
├── check_data.py               # CSV validation script
├── generate_static_dashboard.py # Static dashboard generator
├── simple_dashboard.py         # Simplified dashboard generator
├── generate_pdf_report.py      # PDF report generator
├── simulate_data.py            # Data simulation script
├── data/
│   ├── uploads/                # Directory for uploaded log files
│   └── reports/                # Directory for generated reports
├── modules/
│   ├── parser.py               # Log parsing module
│   ├── analyzer.py             # Data analysis module
│   ├── visualizer.py           # Visualization components
│   ├── reporter.py             # PDF report generation
│   └── notifier.py             # Email notification system
├── static/                     # Static assets for the web interface
├── templates/                  # HTML templates
└── batch/                      # Batch files for easy execution
    ├── install.bat             # Installation script
    ├── start_webapp.bat        # Start web application
    ├── run_pipeline.bat        # Run analysis pipeline
    ├── generate_pdf_report.bat # Generate PDF report
    └── run_simple_dashboard.bat # Generate HTML dashboard
```

## License

MIT

## Contributors

- Security Analyst Team
