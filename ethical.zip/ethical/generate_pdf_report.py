import os
import pandas as pd
import argparse
from datetime import datetime
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend

def generate_pdf_report(csv_file, output_dir="data/reports"):
    """
    Generate a PDF report using the provided CSV file
    
    Args:
        csv_file (str): Path to the CSV file
        output_dir (str): Directory to save the output files
    """
    try:
        # Import reportlab here to avoid dependency issues if not installed
        from reportlab.lib.pagesizes import letter
        from reportlab.lib import colors
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
        from reportlab.lib.units import inch
        
        print(f"Generating PDF report using {csv_file}...")
        
        # Create output directory if it doesn't exist
        os.makedirs(output_dir, exist_ok=True)
        
        # Read the CSV file
        df = pd.read_csv(csv_file)
        
        # Convert timestamp to datetime
        df['Timestamp'] = pd.to_datetime(df['Timestamp'])
        
        # Get basic statistics
        total_events = len(df)
        time_range = f"{df['Timestamp'].min()} to {df['Timestamp'].max()}"
        severity_distribution = dict(df['Level'].value_counts())
        top_event_ids = dict(df['EventID'].value_counts().head(5))
        
        # Create charts directory
        charts_dir = os.path.join(output_dir, "charts")
        os.makedirs(charts_dir, exist_ok=True)
        
        # Generate severity distribution chart
        plt.figure(figsize=(8, 6))
        severity_counts = df['Level'].value_counts()
        colors_map = {'high': 'red', 'medium': 'orange', 'low': 'blue', 'info': 'green'}
        colors_list = [colors_map.get(level.lower(), 'gray') for level in severity_counts.index]
        severity_counts.plot(kind='pie', autopct='%1.1f%%', colors=colors_list)
        plt.title('Event Severity Distribution')
        plt.ylabel('')
        severity_chart_path = os.path.join(charts_dir, "severity_distribution.png")
        plt.savefig(severity_chart_path, bbox_inches='tight')
        plt.close()
        
        # Generate event ID chart
        plt.figure(figsize=(10, 6))
        eventid_counts = df['EventID'].value_counts().head(10)
        eventid_counts.plot(kind='bar', color='skyblue')
        plt.title('Top 10 Event IDs')
        plt.xlabel('Event ID')
        plt.ylabel('Count')
        plt.xticks(rotation=45)
        eventid_chart_path = os.path.join(charts_dir, "top_eventids.png")
        plt.savefig(eventid_chart_path, bbox_inches='tight')
        plt.close()
        
        # Generate timeline chart
        plt.figure(figsize=(12, 6))
        events_per_hour = df.groupby(pd.Grouper(key='Timestamp', freq='1H')).size()
        events_per_hour.plot(kind='line', color='blue')
        plt.title('Events Over Time')
        plt.xlabel('Time')
        plt.ylabel('Number of Events')
        plt.grid(True, linestyle='--', alpha=0.7)
        timeline_chart_path = os.path.join(charts_dir, "timeline.png")
        plt.savefig(timeline_chart_path, bbox_inches='tight')
        plt.close()
        
        # Create PDF report
        report_file = os.path.join(output_dir, f"threat_analysis_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf")
        doc = SimpleDocTemplate(report_file, pagesize=letter)
        
        # Define styles
        styles = getSampleStyleSheet()
        title_style = styles['Title']
        heading_style = styles['Heading1']
        subheading_style = styles['Heading2']
        normal_style = styles['Normal']
        
        # Create content
        content = []
        
        # Title
        content.append(Paragraph("Automated Threat Analysis Report", title_style))
        content.append(Spacer(1, 0.25*inch))
        
        # Summary
        content.append(Paragraph("Analysis Summary", heading_style))
        content.append(Paragraph(f"<b>Report Generated:</b> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", normal_style))
        content.append(Paragraph(f"<b>Total Events Analyzed:</b> {total_events}", normal_style))
        content.append(Paragraph(f"<b>Time Range:</b> {time_range}", normal_style))
        content.append(Paragraph(f"<b>Severity Distribution:</b> {severity_distribution}", normal_style))
        content.append(Spacer(1, 0.25*inch))
        
        # Severity Distribution Chart
        if os.path.exists(severity_chart_path):
            content.append(Paragraph("Severity Distribution", subheading_style))
            content.append(Image(severity_chart_path, width=6*inch, height=4*inch))
            content.append(Spacer(1, 0.25*inch))
        
        # Event ID Chart
        if os.path.exists(eventid_chart_path):
            content.append(Paragraph("Top Event IDs", subheading_style))
            content.append(Image(eventid_chart_path, width=6*inch, height=4*inch))
            content.append(Spacer(1, 0.25*inch))
        
        # Timeline Chart
        if os.path.exists(timeline_chart_path):
            content.append(Paragraph("Event Timeline", subheading_style))
            content.append(Image(timeline_chart_path, width=6*inch, height=3*inch))
            content.append(Spacer(1, 0.25*inch))
        
        # Recent Events Table
        content.append(Paragraph("Recent High-Priority Events", subheading_style))
        
        # Get high priority events or most recent events if none are high priority
        high_priority = df[df['Level'].isin(['high', 'medium'])].sort_values('Timestamp', ascending=False).head(10)
        if len(high_priority) == 0:
            high_priority = df.sort_values('Timestamp', ascending=False).head(10)
        
        # Create table data
        table_data = [["Timestamp", "Event ID", "Description", "Computer", "Severity"]]
        for _, row in high_priority.iterrows():
            description = row.get('RuleTitle', '') if 'RuleTitle' in row else row.get('Details', '')
            if len(description) > 50:  # Truncate long descriptions
                description = description[:47] + "..."
            table_data.append([
                str(row['Timestamp']),
                str(row['EventID']),
                description,
                row['Computer'],
                row['Level']
            ])
        
        # Create table
        table = Table(table_data, colWidths=[1.5*inch, 0.8*inch, 2.5*inch, 1.2*inch, 0.8*inch])
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.white),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 1), (-1, -1), 10),
            ('TOPPADDING', (0, 1), (-1, -1), 8),
            ('BOTTOMPADDING', (0, 1), (-1, -1), 8),
        ]))
        content.append(table)
        
        # Build PDF
        doc.build(content)
        
        print(f"PDF report generated: {report_file}")
        return report_file
        
    except ImportError as e:
        print(f"Error: Required library not installed: {str(e)}")
        print("Please install reportlab and matplotlib: pip install reportlab matplotlib")
        return None
    except Exception as e:
        print(f"Error generating PDF report: {str(e)}")
        return None

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate a PDF report using a CSV file")
    parser.add_argument("--file", default="data/uploads/timeline.csv", help="Path to the CSV file")
    parser.add_argument("--output", default="data/reports", help="Directory to save the output files")
    
    args = parser.parse_args()
    report_file = generate_pdf_report(args.file, args.output)
    
    if report_file and os.path.exists(report_file):
        # Try to open the report in the default PDF viewer
        try:
            import webbrowser
            print(f"Opening report: {report_file}")
            webbrowser.open(f"file://{os.path.abspath(report_file)}")
        except Exception as e:
            print(f"Could not open report automatically: {str(e)}")
            print(f"Please open the report manually at: {report_file}")
