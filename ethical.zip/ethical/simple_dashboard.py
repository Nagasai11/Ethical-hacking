import os
import pandas as pd
import webbrowser
from datetime import datetime
import argparse

def generate_simple_dashboard(csv_file, output_dir="data/reports"):
    """
    Generate a simple HTML dashboard using the provided CSV file
    
    Args:
        csv_file (str): Path to the CSV file
        output_dir (str): Directory to save the output files
    """
    print(f"Generating simple dashboard using {csv_file}...")
    
    # Create output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)
    
    # Read the CSV file
    df = pd.read_csv(csv_file)
    
    # Convert timestamp to datetime
    df['Timestamp'] = pd.to_datetime(df['Timestamp'])
    
    # Get basic statistics
    total_events = len(df)
    time_range = f"{df['Timestamp'].min()} to {df['Timestamp'].max()}"
    severity_distribution = dict(df['Level'].value_counts())
    top_event_ids = dict(df['EventID'].value_counts().head(5))
    
    # Generate severity distribution table
    severity_counts = df['Level'].value_counts()
    severity_rows = ""
    for level, count in severity_counts.items():
        percentage = (count / len(df)) * 100
        severity_rows += f"<tr><td>{level}</td><td>{count}</td><td>{percentage:.2f}%</td></tr>"
    
    # Generate event ID distribution table
    eventid_counts = df['EventID'].value_counts().head(10)
    eventid_rows = ""
    for event_id, count in eventid_counts.items():
        percentage = (count / len(df)) * 100
        eventid_rows += f"<tr><td>{event_id}</td><td>{count}</td><td>{percentage:.2f}%</td></tr>"
    
    # Generate recent events table
    recent_events = df.sort_values('Timestamp', ascending=False).head(20)
    recent_events_rows = ""
    for _, row in recent_events.iterrows():
        description = row.get('RuleTitle', '') if 'RuleTitle' in row else row.get('Details', '')
        recent_events_rows += f"<tr><td>{row['Timestamp']}</td><td>{row['EventID']}</td><td>{description}</td><td>{row['Computer']}</td><td>{row['Level']}</td></tr>"
    
    # Create HTML content
    html_content = f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Automated Threat Analysis Dashboard</title>
        <style>
            body {{ font-family: Arial, sans-serif; margin: 20px; }}
            .container {{ max-width: 1200px; margin: 0 auto; }}
            .header {{ text-align: center; margin-bottom: 30px; }}
            .section {{ margin-bottom: 30px; padding: 15px; border: 1px solid #ddd; }}
            table {{ width: 100%; border-collapse: collapse; }}
            th, td {{ padding: 8px; text-align: left; border-bottom: 1px solid #ddd; }}
            th {{ background-color: #f2f2f2; }}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>Automated Threat Analysis Dashboard</h1>
                <p>Generated on {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}</p>
            </div>
            
            <div class="section">
                <h2>Analysis Summary</h2>
                <p><strong>Total events analyzed:</strong> {total_events}</p>
                <p><strong>Time range:</strong> {time_range}</p>
                <p><strong>Severity distribution:</strong> {severity_distribution}</p>
                <p><strong>Top Event IDs:</strong> {top_event_ids}</p>
            </div>
            
            <div class="section">
                <h2>Events by Severity</h2>
                <table>
                    <tr>
                        <th>Severity</th>
                        <th>Count</th>
                        <th>Percentage</th>
                    </tr>
                    {severity_rows}
                </table>
            </div>
            
            <div class="section">
                <h2>Top 10 Event IDs</h2>
                <table>
                    <tr>
                        <th>Event ID</th>
                        <th>Count</th>
                        <th>Percentage</th>
                    </tr>
                    {eventid_rows}
                </table>
            </div>
            
            <div class="section">
                <h2>Recent Events</h2>
                <table>
                    <tr>
                        <th>Timestamp</th>
                        <th>Event ID</th>
                        <th>Description</th>
                        <th>Computer</th>
                        <th>Severity</th>
                    </tr>
                    {recent_events_rows}
                </table>
            </div>
        </div>
    </body>
    </html>
    """
    
    # Write the HTML file
    output_file = os.path.join(output_dir, "simple_dashboard.html")
    with open(output_file, "w") as f:
        f.write(html_content)
    
    print(f"Dashboard generated: {output_file}")
    return output_file

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate a simple HTML dashboard using a CSV file")
    parser.add_argument("--file", default="data/uploads/timeline.csv", help="Path to the CSV file")
    parser.add_argument("--output", default="data/reports", help="Directory to save the output files")
    
    args = parser.parse_args()
    dashboard_file = generate_simple_dashboard(args.file, args.output)
    
    # Try to open the dashboard in the default browser
    try:
        print(f"Opening dashboard in browser: {dashboard_file}")
        webbrowser.open(f"file://{os.path.abspath(dashboard_file)}")
    except Exception as e:
        print(f"Could not open dashboard in browser: {str(e)}")
        print(f"Please open the dashboard manually: {dashboard_file}")
