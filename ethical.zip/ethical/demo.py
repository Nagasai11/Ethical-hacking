import os
import argparse
import logging
from datetime import datetime
import pandas as pd
import webbrowser
import time
import subprocess

# Import project modules
from modules.parser import simulate_parsed_data, read_csv_to_dataframe
from modules.analyzer import analyze_data
from modules.visualizer import create_visualizations
from modules.reporter import generate_report
from modules.notifier import send_email_notification
import config

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("demo.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def run_demo(use_real_data=False, send_email=False, open_browser=True):
    """
    Run a demonstration of the full analysis pipeline
    
    Args:
        use_real_data (bool): Whether to use real data from data/uploads/timeline.csv
        send_email (bool): Whether to send email notification
        open_browser (bool): Whether to open the web browser
    """
    try:
        print("=" * 80)
        print("AUTOMATED THREAT ANALYSIS AND VISUALIZATION TOOL - DEMO")
        print("=" * 80)
        print(f"Starting demo at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print("=" * 80)
        
        # Create necessary directories
        os.makedirs('data/uploads', exist_ok=True)
        os.makedirs('data/reports', exist_ok=True)
        
        # Step 1: Parse logs
        print("\n[Step 1] Parsing logs...")
        if use_real_data and os.path.exists('data/uploads/timeline.csv'):
            print("Using real data from data/uploads/timeline.csv")
            df = read_csv_to_dataframe('data/uploads/timeline.csv')
        else:
            print("Using simulated data")
            df = simulate_parsed_data()
            # Save simulated data for reference
            df.to_csv('data/uploads/simulated_data.csv', index=False)
            print("Saved simulated data to data/uploads/simulated_data.csv")
        
        print(f"Parsed {len(df)} log entries")
        
        # Step 2: Analyze data
        print("\n[Step 2] Analyzing data...")
        analysis_results = analyze_data(df)
        
        # Print summary of analysis
        severity_distribution = analysis_results.get('severity_distribution', {})
        print(f"Severity distribution: {severity_distribution}")
        
        potential_attacks = analysis_results.get('potential_attacks', [])
        if potential_attacks:
            print("\nPotential attacks detected:")
            for attack in potential_attacks:
                print(f"- {attack.get('type')}: {attack.get('evidence')} (Severity: {attack.get('severity')})")
        
        # Step 3: Create visualizations
        print("\n[Step 3] Creating visualizations...")
        visualizations = create_visualizations(analysis_results)
        print(f"Created {len(visualizations)} visualizations")
        
        # Step 4: Generate report
        print("\n[Step 4] Generating report...")
        report_file = generate_report(analysis_results, visualizations, 'data/reports')
        print(f"Report generated: {report_file}")
        
        # Step 5: Send email notification if requested
        if send_email:
            print("\n[Step 5] Sending email notification...")
            high_severity_count = severity_distribution.get('high', 0)
            
            email_sent = send_email_notification(
                report_file,
                config.Config.MAIL_RECIPIENTS,
                config.Config.MAIL_SERVER,
                config.Config.MAIL_PORT,
                config.Config.MAIL_USERNAME,
                config.Config.MAIL_PASSWORD,
                config.Config.MAIL_DEFAULT_SENDER,
                config.Config.MAIL_USE_TLS,
                high_severity_count
            )
            
            if email_sent:
                print("Email notification sent successfully")
            else:
                print("Failed to send email notification")
        
        print("\n[Demo Complete] All steps executed successfully")
        
        # Open the report in the default PDF viewer
        if os.path.exists(report_file) and open_browser:
            print(f"\nOpening report: {report_file}")
            try:
                os.startfile(report_file)
            except Exception as e:
                print(f"Could not open report automatically: {str(e)}")
                print(f"Please open the report manually at: {report_file}")
        
        # Start the web application
        if open_browser:
            print("\nStarting web application...")
            print("Please wait while the server starts...")
            
            # Start the web app in a separate process
            web_app_process = subprocess.Popen(
                ["python", "start_app.py"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            
            # Wait for the server to start
            time.sleep(5)
            
            # Open the web browser
            print("Opening web browser...")
            webbrowser.open('http://127.0.0.1:8050')
            
            print("\nPress Ctrl+C to stop the demo when finished")
            try:
                # Keep the script running until user interrupts
                while True:
                    time.sleep(1)
            except KeyboardInterrupt:
                print("\nStopping demo...")
                web_app_process.terminate()
                print("Demo stopped")
        
        return True
        
    except Exception as e:
        logger.exception(f"Error in demo: {str(e)}")
        print(f"\n[ERROR] {str(e)}")
        return False

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run a demonstration of the Automated Threat Analysis and Visualization Tool")
    parser.add_argument("--real-data", action="store_true", help="Use real data from data/uploads/timeline.csv")
    parser.add_argument("--send-email", action="store_true", help="Send email notification")
    parser.add_argument("--no-browser", action="store_true", help="Do not open web browser")
    
    args = parser.parse_args()
    run_demo(args.real_data, args.send_email, not args.no_browser)
