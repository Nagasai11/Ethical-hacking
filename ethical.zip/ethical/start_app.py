import os
import argparse
import logging
from app import app

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("app.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def start_app(host='127.0.0.1', port=8050, debug=True):
    """
    Start the Flask/Dash web application
    
    Args:
        host (str): Host to run the app on
        port (int): Port to run the app on
        debug (bool): Whether to run in debug mode
    """
    try:
        # Create necessary directories
        os.makedirs('data', exist_ok=True)
        os.makedirs('data/uploads', exist_ok=True)
        os.makedirs('data/reports', exist_ok=True)
        
        logger.info(f"Starting application on {host}:{port}")
        app.run_server(host=host, port=port, debug=debug)
        
    except Exception as e:
        logger.exception(f"Error starting application: {str(e)}")
        raise

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Start the Automated Threat Analysis and Visualization Tool")
    parser.add_argument("--host", default="127.0.0.1", help="Host to run the app on")
    parser.add_argument("--port", type=int, default=8050, help="Port to run the app on")
    parser.add_argument("--no-debug", action="store_true", help="Disable debug mode")
    
    args = parser.parse_args()
    start_app(args.host, args.port, not args.no_debug)
