import os
import dash
from dash import dcc, html
from dash.dependencies import Input, Output
import dash_bootstrap_components as dbc
import flask
from modules.parser import parse_logs
from modules.analyzer import analyze_data
from modules.visualizer import create_visualizations
from modules.reporter import generate_report
from modules.notifier import send_email_notification
import config

# Initialize Flask server
server = flask.Flask(__name__)
server.config.from_object(config.Config)

# Initialize Dash app
app = dash.Dash(
    __name__,
    server=server,
    external_stylesheets=[dbc.themes.BOOTSTRAP],
    suppress_callback_exceptions=True
)

# Define the layout
app.layout = html.Div([
    dbc.NavbarSimple(
        brand="Automated Threat Analysis and Visualization Tool",
        brand_href="/",
        color="dark",
        dark=True,
    ),
    
    dbc.Container([
        dbc.Row([
            dbc.Col([
                html.H2("Windows Event Log Analysis", className="mt-4"),
                html.Hr(),
                
                # File Upload Component
                dcc.Upload(
                    id='upload-data',
                    children=html.Div([
                        'Drag and Drop or ',
                        html.A('Select EVTX Files')
                    ]),
                    style={
                        'width': '100%',
                        'height': '60px',
                        'lineHeight': '60px',
                        'borderWidth': '1px',
                        'borderStyle': 'dashed',
                        'borderRadius': '5px',
                        'textAlign': 'center',
                        'margin': '10px'
                    },
                    multiple=True
                ),
                
                html.Div(id='upload-status'),
                
                # Analysis Controls
                dbc.Card([
                    dbc.CardHeader("Analysis Controls"),
                    dbc.CardBody([
                        dbc.Button("Run Analysis", id="run-analysis", color="primary", className="mr-2"),
                        dbc.Button("Generate Report", id="generate-report", color="success", className="mr-2"),
                        dbc.Button("Send Email Report", id="send-email", color="info"),
                    ])
                ], className="mt-3 mb-3"),
                
                # Status Output
                html.Div(id='analysis-status')
            ], width=12)
        ]),
        
        # Dashboard Tabs
        dbc.Row([
            dbc.Col([
                dbc.Tabs([
                    dbc.Tab(label="Event Timeline", tab_id="tab-timeline", children=[
                        html.Div(id="timeline-content", className="pt-3")
                    ]),
                    dbc.Tab(label="Severity Distribution", tab_id="tab-severity", children=[
                        html.Div(id="severity-content", className="pt-3")
                    ]),
                    dbc.Tab(label="Critical Events", tab_id="tab-critical", children=[
                        html.Div(id="critical-content", className="pt-3")
                    ]),
                ], id="tabs", active_tab="tab-timeline")
            ], width=12)
        ])
    ], fluid=True)
])

# Callback for file upload
@app.callback(
    Output('upload-status', 'children'),
    Input('upload-data', 'contents'),
    Input('upload-data', 'filename')
)
def update_output(contents, filenames):
    if contents is None:
        return html.Div("No files uploaded yet.")
    
    if not all(filename.endswith('.evtx') for filename in filenames):
        return html.Div("Please upload only .evtx files.", style={'color': 'red'})
    
    return html.Div([
        html.H5(f"Uploaded {len(filenames)} file(s):"),
        html.Ul([html.Li(filename) for filename in filenames])
    ])

# Callback for running analysis
@app.callback(
    Output('analysis-status', 'children'),
    Input('run-analysis', 'n_clicks'),
    Input('upload-data', 'contents'),
    Input('upload-data', 'filename')
)
def run_analysis(n_clicks, contents, filenames):
    if n_clicks is None or contents is None:
        return html.Div("Click 'Run Analysis' after uploading files.")
    
    # This would actually call Hayabusa and process the logs
    # For now, we'll simulate the process
    return html.Div([
        html.H5("Analysis Complete", style={'color': 'green'}),
        html.P("Processed logs and identified events. View the tabs below for results.")
    ])

# Callback for timeline visualization
@app.callback(
    Output('timeline-content', 'children'),
    Input('tabs', 'active_tab'),
    Input('analysis-status', 'children')
)
def render_timeline_content(active_tab, analysis_status):
    if active_tab != 'tab-timeline' or "Analysis Complete" not in str(analysis_status):
        return html.Div()
    
    # This would actually generate visualizations based on analyzed data
    # For now, we'll create a placeholder
    return html.Div([
        html.H4("Event Timeline"),
        dcc.Graph(
            figure={
                'data': [
                    {'x': ['2023-01-01', '2023-01-02', '2023-01-03'], 
                     'y': [5, 10, 3], 
                     'type': 'scatter', 
                     'name': 'High Severity'},
                    {'x': ['2023-01-01', '2023-01-02', '2023-01-03'], 
                     'y': [15, 12, 8], 
                     'type': 'scatter', 
                     'name': 'Medium Severity'},
                    {'x': ['2023-01-01', '2023-01-02', '2023-01-03'], 
                     'y': [20, 18, 22], 
                     'type': 'scatter', 
                     'name': 'Low Severity'}
                ],
                'layout': {
                    'title': 'Event Frequency Over Time',
                    'xaxis': {'title': 'Date'},
                    'yaxis': {'title': 'Number of Events'}
                }
            }
        )
    ])

# Callback for severity distribution
@app.callback(
    Output('severity-content', 'children'),
    Input('tabs', 'active_tab'),
    Input('analysis-status', 'children')
)
def render_severity_content(active_tab, analysis_status):
    if active_tab != 'tab-severity' or "Analysis Complete" not in str(analysis_status):
        return html.Div()
    
    return html.Div([
        html.H4("Severity Distribution"),
        dcc.Graph(
            figure={
                'data': [
                    {'values': [18, 35, 47], 
                     'labels': ['High', 'Medium', 'Low'], 
                     'type': 'pie',
                     'marker': {'colors': ['#ff0000', '#ffa500', '#ffff00']}}
                ],
                'layout': {
                    'title': 'Event Severity Distribution'
                }
            }
        )
    ])

# Callback for critical events
@app.callback(
    Output('critical-content', 'children'),
    Input('tabs', 'active_tab'),
    Input('analysis-status', 'children')
)
def render_critical_content(active_tab, analysis_status):
    if active_tab != 'tab-critical' or "Analysis Complete" not in str(analysis_status):
        return html.Div()
    
    # This would show actual critical events from the analysis
    return html.Div([
        html.H4("Critical Events"),
        dbc.Table([
            html.Thead(html.Tr([
                html.Th("Timestamp"), 
                html.Th("Event ID"), 
                html.Th("Description"),
                html.Th("Severity")
            ])),
            html.Tbody([
                html.Tr([
                    html.Td("2023-01-02 14:35:22"), 
                    html.Td("4624"), 
                    html.Td("Successful logon from unusual IP address"),
                    html.Td("High")
                ]),
                html.Tr([
                    html.Td("2023-01-02 14:36:45"), 
                    html.Td("4672"), 
                    html.Td("Special privileges assigned to new logon"),
                    html.Td("High")
                ]),
                html.Tr([
                    html.Td("2023-01-02 14:40:12"), 
                    html.Td("7045"), 
                    html.Td("New service was installed"),
                    html.Td("High")
                ])
            ])
        ], bordered=True, hover=True, responsive=True)
    ])

# Callback for report generation
@app.callback(
    Output('generate-report', 'children'),
    Input('generate-report', 'n_clicks'),
    Input('analysis-status', 'children')
)
def handle_report_generation(n_clicks, analysis_status):
    if n_clicks is None or "Analysis Complete" not in str(analysis_status):
        return "Generate Report"
    
    # This would actually generate a PDF report
    # For now, we'll just update the button text
    return "Report Generated"

# Callback for email sending
@app.callback(
    Output('send-email', 'children'),
    Input('send-email', 'n_clicks'),
    Input('generate-report', 'children')
)
def handle_email_sending(n_clicks, report_status):
    if n_clicks is None or report_status != "Report Generated":
        return "Send Email Report"
    
    # This would actually send an email with the report
    # For now, we'll just update the button text
    return "Email Sent"

if __name__ == '__main__':
    # Create necessary directories if they don't exist
    os.makedirs('data', exist_ok=True)
    os.makedirs('data/uploads', exist_ok=True)
    os.makedirs('data/reports', exist_ok=True)
    
    # Run the app
    app.run_server(debug=True, port=8050)
