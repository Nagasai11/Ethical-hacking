import os
import argparse
import logging
from datetime import datetime
import schedule
import time
from modules.parser import parse_logs, simulate_parsed_data, read_csv_to_dataframe
from modules.analyzer import analyze_data, get_critical_events
from modules.visualizer import create_visualizations
from modules.reporter import generate_report
from modules.notifier import send_email_notification
import config

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("pipeline.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def run_analysis_pipeline(evtx_files=None, simulate=False, send_email=False):
    """
    Run the complete analysis pipeline
    
    Args:
        evtx_files (list): List of paths to EVTX files
        simulate (bool): Whether to use simulated data
        send_email (bool): Whether to send email notification
        
    Returns:
        dict: Dictionary containing pipeline results
    """
    try:
        logger.info("Starting analysis pipeline")
        
        # Create necessary directories
        os.makedirs(config.Config.UPLOAD_FOLDER, exist_ok=True)
        os.makedirs(config.Config.REPORT_FOLDER, exist_ok=True)
        
        # Step 1: Parse logs
        if simulate:
            logger.info("Using simulated data for analysis")
            df = simulate_parsed_data()
            csv_file = None
        else:
            if not evtx_files:
                logger.error("No EVTX files provided and simulation is disabled")
                return {"error": "No EVTX files provided"}
            
            logger.info(f"Parsing {len(evtx_files)} EVTX files")
            csv_file = parse_logs(
                evtx_files, 
                config.Config.HAYABUSA_PATH,
                config.Config.SIGMA_RULES_PATH,
                config.Config.UPLOAD_FOLDER
            )
            df = read_csv_to_dataframe(csv_file)
        
        # Step 2: Analyze data
        logger.info("Analyzing parsed data")
        analysis_results = analyze_data(df)
        
        # Extract high severity count for email notification
        high_severity_count = analysis_results.get('severity_distribution', {}).get('high', 0)
        
        # Step 3: Create visualizations
        logger.info("Creating visualizations")
        visualizations = create_visualizations(analysis_results)
        
        # Step 4: Generate report
        logger.info("Generating report")
        report_file = generate_report(analysis_results, visualizations, config.Config.REPORT_FOLDER)
        
        # Step 5: Send email notification if requested
        if send_email:
            logger.info("Sending email notification")
            email_sent = send_email_notification(
                report_file,
                config.Config.MAIL_RECIPIENTS,
                config.Config.MAIL_SERVER,
                config.Config.MAIL_PORT,
                config.Config.MAIL_USERNAME,
                config.Config.MAIL_PASSWORD,
                config.Config.MAIL_DEFAULT_SENDER,
                config.Config.MAIL_USE_TLS,
                high_severity_count
            )
            
            if email_sent:
                logger.info("Email notification sent successfully")
            else:
                logger.warning("Failed to send email notification")
        
        logger.info("Analysis pipeline completed successfully")
        
        return {
            "status": "success",
            "csv_file": csv_file,
            "report_file": report_file,
            "high_severity_count": high_severity_count
        }
        
    except Exception as e:
        logger.exception(f"Error in analysis pipeline: {str(e)}")
        return {"error": str(e)}

def schedule_pipeline(interval_hours, evtx_files=None, simulate=False, send_email=False):
    """
    Schedule the analysis pipeline to run at regular intervals
    
    Args:
        interval_hours (int): Interval in hours
        evtx_files (list): List of paths to EVTX files
        simulate (bool): Whether to use simulated data
        send_email (bool): Whether to send email notification
    """
    logger.info(f"Scheduling pipeline to run every {interval_hours} hours")
    
    # Define the job
    def job():
        logger.info(f"Running scheduled pipeline at {datetime.now()}")
        run_analysis_pipeline(evtx_files, simulate, send_email)
    
    # Schedule the job
    schedule.every(interval_hours).hours.do(job)
    
    # Run the job immediately
    job()
    
    # Keep the script running
    while True:
        schedule.run_pending()
        time.sleep(60)

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Windows Event Log Analysis Pipeline")
    parser.add_argument("--evtx", nargs="+", help="Paths to EVTX files")
    parser.add_argument("--simulate", action="store_true", help="Use simulated data")
    parser.add_argument("--schedule", type=int, help="Schedule interval in hours")
    parser.add_argument("--email", action="store_true", help="Send email notification")
    
    args = parser.parse_args()
    
    if args.schedule:
        schedule_pipeline(args.schedule, args.evtx, args.simulate, args.email)
    else:
        run_analysis_pipeline(args.evtx, args.simulate, args.email)
