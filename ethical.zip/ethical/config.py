import os

class Config:
    # Flask configuration
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'you-will-never-guess'
    DEBUG = True
    
    # File upload configuration
    UPLOAD_FOLDER = os.path.join(os.getcwd(), 'data', 'uploads')
    MAX_CONTENT_LENGTH = 100 * 1024 * 1024  # 100 MB max upload size
    
    # Report configuration
    REPORT_FOLDER = os.path.join(os.getcwd(), 'data', 'reports')
    
    # Email configuration
    MAIL_SERVER = os.environ.get('MAIL_SERVER') or 'smtp.gmail.com'
    MAIL_PORT = int(os.environ.get('MAIL_PORT') or 587)
    MAIL_USE_TLS = True
    MAIL_USERNAME = os.environ.get('MAIL_USERNAME') or 'your-email@gmail.com'
    MAIL_PASSWORD = os.environ.get('MAIL_PASSWORD') or 'your-password'
    MAIL_DEFAULT_SENDER = os.environ.get('MAIL_DEFAULT_SENDER') or 'your-email@gmail.com'
    MAIL_RECIPIENTS = os.environ.get('MAIL_RECIPIENTS') or ['admin@example.com']
    
    # Hayabusa configuration
    HAYABUSA_PATH = os.environ.get('HAYABUSA_PATH') or os.path.join(os.getcwd(), 'hayabusa', 'hayabusa.exe')
    SIGMA_RULES_PATH = os.environ.get('SIGMA_RULES_PATH') or os.path.join(os.getcwd(), 'hayabusa', 'rules')
    
    # Scheduling configuration
    SCHEDULE_INTERVAL = int(os.environ.get('SCHEDULE_INTERVAL') or 6)  # Hours
