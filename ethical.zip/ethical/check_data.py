import os
import pandas as pd
import argparse
import sys

def check_csv_file(file_path):
    """
    Check if a CSV file is valid and contains the expected columns
    
    Args:
        file_path (str): Path to the CSV file
        
    Returns:
        bool: True if the file is valid, False otherwise
    """
    try:
        if not os.path.exists(file_path):
            print(f"Error: File not found: {file_path}")
            return False
        
        # Try to read the CSV file
        df = pd.read_csv(file_path)
        
        # Check if it has any rows
        if len(df) == 0:
            print(f"Warning: File is empty: {file_path}")
            return False
        
        # Check for essential columns (adjust as needed)
        essential_columns = ['Timestamp', 'EventID']
        missing_essential = [col for col in essential_columns if col not in df.columns]
        
        if missing_essential:
            print(f"Warning: Missing essential columns: {', '.join(missing_essential)}")
            print(f"Available columns: {', '.join(df.columns)}")
            return False
        
        # Print summary
        print(f"File is valid: {file_path}")
        print(f"Number of rows: {len(df)}")
        print(f"Columns: {', '.join(df.columns)}")
        
        # Check for common Hayabusa columns
        hayabusa_columns = {
            'Timestamp': 'Event timestamp',
            'RuleTitle': 'Title of the detection rule',
            'Level': 'Severity level',
            'Computer': 'Computer name',
            'Channel': 'Event log channel',
            'EventID': 'Windows Event ID',
            'RecordID': 'Record ID',
            'Details': 'Event details',
            'RuleID': 'ID of the detection rule'
        }
        
        print("\nDetected Hayabusa columns:")
        for col, desc in hayabusa_columns.items():
            if col in df.columns:
                print(f"- {col}: {desc}")
        
        if 'Level' in df.columns:
            severity_counts = df['Level'].value_counts().to_dict()
            print(f"\nSeverity distribution: {severity_counts}")
        
        if 'EventID' in df.columns:
            event_id_counts = df['EventID'].value_counts().head(5).to_dict()
            print(f"\nTop 5 Event IDs: {event_id_counts}")
        
        # Check for potential description column
        description_candidates = ['Description', 'RuleTitle', 'Details']
        found_desc = False
        for col in description_candidates:
            if col in df.columns:
                print(f"\nUsing '{col}' as description column")
                # Show a sample
                print(f"Sample {col}: {df[col].iloc[0] if len(df) > 0 else 'N/A'}")
                found_desc = True
                break
        
        if not found_desc:
            print("\nWarning: No suitable description column found")
        
        return True
        
    except Exception as e:
        print(f"Error checking file: {str(e)}")
        return False

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Check if a CSV file is valid for the analysis pipeline")
    parser.add_argument("--file", default="C:\\Users\\nagas\\Downloads\\output\\test.csv", help="Path to the CSV file")
    
    args = parser.parse_args()
    
    if not check_csv_file(args.file):
        sys.exit(1)
    
    sys.exit(0)
