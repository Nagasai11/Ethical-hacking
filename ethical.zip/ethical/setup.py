import os
import sys
import subprocess
import argparse
import logging
import zipfile
import shutil
import requests
from tqdm import tqdm

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("setup.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def download_file(url, destination):
    """
    Download a file from a URL with progress bar
    
    Args:
        url (str): URL to download
        destination (str): Destination file path
        
    Returns:
        bool: True if download was successful, False otherwise
    """
    try:
        response = requests.get(url, stream=True)
        total_size = int(response.headers.get('content-length', 0))
        
        with open(destination, 'wb') as f, tqdm(
            desc=os.path.basename(destination),
            total=total_size,
            unit='B',
            unit_scale=True,
            unit_divisor=1024,
        ) as bar:
            for data in response.iter_content(chunk_size=1024):
                size = f.write(data)
                bar.update(size)
        
        return True
    except Exception as e:
        logger.exception(f"Error downloading file: {str(e)}")
        return False

def setup_hayabusa(hayabusa_dir, version="2.12.0"):
    """
    Download and set up Hayabusa
    
    Args:
        hayabusa_dir (str): Directory to install Hayabusa
        version (str): Hayabusa version to install
        
    Returns:
        bool: True if setup was successful, False otherwise
    """
    try:
        logger.info(f"Setting up Hayabusa v{version} in {hayabusa_dir}")
        
        # Create directory if it doesn't exist
        os.makedirs(hayabusa_dir, exist_ok=True)
        
        # Download Hayabusa
        hayabusa_url = f"https://github.com/Yamato-Security/hayabusa/releases/download/v{version}/hayabusa-{version}-win-x64.zip"
        hayabusa_zip = os.path.join(hayabusa_dir, f"hayabusa-{version}.zip")
        
        logger.info(f"Downloading Hayabusa from {hayabusa_url}")
        if not download_file(hayabusa_url, hayabusa_zip):
            logger.error("Failed to download Hayabusa")
            return False
        
        # Extract Hayabusa
        logger.info(f"Extracting Hayabusa to {hayabusa_dir}")
        with zipfile.ZipFile(hayabusa_zip, 'r') as zip_ref:
            zip_ref.extractall(hayabusa_dir)
        
        # Remove the zip file
        os.remove(hayabusa_zip)
        
        # Download Sigma rules
        sigma_url = "https://github.com/SigmaHQ/sigma/archive/refs/heads/master.zip"
        sigma_zip = os.path.join(hayabusa_dir, "sigma.zip")
        
        logger.info(f"Downloading Sigma rules from {sigma_url}")
        if not download_file(sigma_url, sigma_zip):
            logger.error("Failed to download Sigma rules")
            return False
        
        # Extract Sigma rules
        sigma_dir = os.path.join(hayabusa_dir, "rules")
        os.makedirs(sigma_dir, exist_ok=True)
        
        logger.info(f"Extracting Sigma rules to {sigma_dir}")
        with zipfile.ZipFile(sigma_zip, 'r') as zip_ref:
            # Extract only the rules directory
            for file in zip_ref.namelist():
                if file.startswith('sigma-master/rules/'):
                    zip_ref.extract(file, hayabusa_dir)
        
        # Move the rules to the correct location
        extracted_rules = os.path.join(hayabusa_dir, "sigma-master", "rules")
        if os.path.exists(extracted_rules):
            # Copy all files from extracted_rules to sigma_dir
            for item in os.listdir(extracted_rules):
                s = os.path.join(extracted_rules, item)
                d = os.path.join(sigma_dir, item)
                if os.path.isdir(s):
                    shutil.copytree(s, d, dirs_exist_ok=True)
                else:
                    shutil.copy2(s, d)
        
        # Remove the zip file and extracted directory
        os.remove(sigma_zip)
        shutil.rmtree(os.path.join(hayabusa_dir, "sigma-master"), ignore_errors=True)
        
        # Test Hayabusa
        hayabusa_exe = os.path.join(hayabusa_dir, "hayabusa.exe")
        if not os.path.exists(hayabusa_exe):
            logger.error(f"Hayabusa executable not found at {hayabusa_exe}")
            return False
        
        logger.info("Testing Hayabusa installation")
        try:
            result = subprocess.run([hayabusa_exe, "--version"], capture_output=True, text=True)
            logger.info(f"Hayabusa version: {result.stdout.strip()}")
        except Exception as e:
            logger.exception(f"Error testing Hayabusa: {str(e)}")
            return False
        
        logger.info("Hayabusa setup completed successfully")
        return True
        
    except Exception as e:
        logger.exception(f"Error setting up Hayabusa: {str(e)}")
        return False

def setup_project():
    """
    Set up the project by creating necessary directories and installing dependencies
    
    Returns:
        bool: True if setup was successful, False otherwise
    """
    try:
        logger.info("Setting up project")
        
        # Create necessary directories
        os.makedirs("data", exist_ok=True)
        os.makedirs("data/uploads", exist_ok=True)
        os.makedirs("data/reports", exist_ok=True)
        os.makedirs("hayabusa", exist_ok=True)
        
        # Install Python dependencies
        logger.info("Installing Python dependencies")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        except Exception as e:
            logger.exception(f"Error installing Python dependencies: {str(e)}")
            return False
        
        # Set up Hayabusa
        if not setup_hayabusa("hayabusa"):
            logger.error("Failed to set up Hayabusa")
            return False
        
        logger.info("Project setup completed successfully")
        return True
        
    except Exception as e:
        logger.exception(f"Error setting up project: {str(e)}")
        return False

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Setup script for Automated Threat Analysis and Visualization Tool")
    parser.add_argument("--hayabusa-only", action="store_true", help="Only set up Hayabusa")
    parser.add_argument("--hayabusa-dir", default="hayabusa", help="Directory to install Hayabusa")
    parser.add_argument("--hayabusa-version", default="2.12.0", help="Hayabusa version to install")
    
    args = parser.parse_args()
    
    if args.hayabusa_only:
        setup_hayabusa(args.hayabusa_dir, args.hayabusa_version)
    else:
        setup_project()
