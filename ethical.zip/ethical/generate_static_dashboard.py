import os
import pandas as pd
import json
import webbrowser
from datetime import datetime
import argparse

def generate_static_dashboard(csv_file, output_dir="data/reports"):
    """
    Generate a static HTML dashboard using the provided CSV file
    
    Args:
        csv_file (str): Path to the CSV file
        output_dir (str): Directory to save the output files
    """
    print(f"Generating static dashboard using {csv_file}...")
    
    # Create output directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)
    
    # Read the CSV file
    try:
        df = pd.read_csv(csv_file)
    except FileNotFoundError:
        print(f"Error: CSV file '{csv_file}' not found.")
        return None
    except Exception as e:
        print(f"Error reading CSV file: {str(e)}")
        return None
    
    # Convert timestamp to datetime
    try:
        df['Timestamp'] = pd.to_datetime(df['Timestamp'])
    except Exception as e:
        print(f"Error converting Timestamp to datetime: {str(e)}")
        return None
    
    # Generate severity distribution table
    severity_counts = df['Level'].value_counts()
    severity_rows = ""
    for level, count in severity_counts.items():
        percentage = (count / len(df)) * 100
        severity_class = f"severity-{level.lower()}"
        severity_rows += f"""
        <tr>
            <td class="{severity_class}">{level}</td>
            <td>{count}</td>
            <td>{percentage:.2f}%</td>
        </tr>
        """
    
    # Generate event ID distribution table
    eventid_counts = df['EventID'].value_counts().head(10)
    eventid_rows = ""
    for event_id, count in eventid_counts.items():
        percentage = (count / len(df)) * 100
        eventid_rows += f"""
        <tr>
            <td>{event_id}</td>
            <td>{count}</td>
            <td>{percentage:.2f}%</td>
        </tr>
        """
    
    # Generate recent events table
    recent_events = df.sort_values('Timestamp', ascending=False).head(20)
    recent_events_rows = ""
    for _, row in recent_events.iterrows():
        description = row.get('RuleTitle', row.get('Details', ''))
        severity_class = f"severity-{row['Level'].lower()}"
        recent_events_rows += f"""
        <tr>
            <td>{row['Timestamp']}</td>
            <td>{row['EventID']}</td>
            <td>{description}</td>
            <td>{row['Computer']}</td>
            <td class="{severity_class}">{row['Level']}</td>
        </tr>
        """
    
    # Create HTML content
    html_content = """
    <!DOCTYPE html>
    <html>
    <head>
        <title>Automated Threat Analysis Dashboard</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
            body {{
                font-family: Arial, sans-serif;
                margin: 0;
                padding: 20px;
                background-color: #f5f5f5;
            }}
            .container {{
                max-width: 1200px;
                margin: 0 auto;
                background-color: white;
                padding: 20px;
                box-shadow: 0 0 10px rgba(0,0,0,0.1);
            }}
            .header {{
                text-align: center;
                margin-bottom: 30px;
            }}
            .chart-container {{
                margin-bottom: 30px;
                padding: 15px;
                background-color: white;
                border-radius: 5px;
                box-shadow: 0 0 5px rgba(0,0,0,0.1);
            }}
            .summary {{
                margin-bottom: 20px;
                padding: 15px;
                background-color: #f9f9f9;
                border-left: 4px solid #007bff;
            }}
            .severity-high {{
                color: #d9534f;
                font-weight: bold;
            }}
            .severity-medium {{
                color: #f0ad4e;
                font-weight: bold;
            }}
            .severity-low {{
                color: #5bc0de;
            }}
            .severity-info {{
                color: #5cb85c;
            }}
            table {{
                width: 100%;
                border-collapse: collapse;
                margin-bottom: 20px;
            }}
            th, td {{
                padding: 12px;
                text-align: left;
                border-bottom: 1px solid #ddd;
            }}
            th {{
                background-color: #f2f2f2;
            }}
            tr:hover {{
                background-color: #f5f5f5;
            }}
            .chart {{
                width: 100%;
                height: 400px;
                border: 1px solid #ddd;
                margin-bottom: 20px;
            }}
            .bar {{
                fill: #007bff;
            }}
            .bar:hover {{
                fill: #0056b3;
            }}
         </style>
     </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>Automated Threat Analysis Dashboard</h1>
                <p>Generated on {timestamp}</p>
            </div>
            
            <div class="summary">
                <h2>Analysis Summary</h2>
                <p><strong>Total events analyzed:</strong> {total_events}</p>
                <p><strong>Time range:</strong> {time_range}</p>
                <p><strong>Severity distribution:</strong> {severity_distribution}</p>
                <p><strong>Top Event IDs:</strong> {top_event_ids}</p>
            </div>
            
            <div class="chart-container">
                <h2>Events by Severity</h2>
                <table>
                    <tr>
                        <th>Severity</th>
                        <th>Count</th>
                        <th>Percentage</th>
                    </tr>
                    {severity_rows}
                </table>
            </div>
            
            <div class="chart-container">
                <h2>Top 10 Event IDs</h2>
                <table>
                    <tr>
                        <th>Event ID</th>
                        <th>Count</th>
                        <th>Percentage</th>
                    </tr>
                    {eventid_rows}
                </table>
            </div>
            
            <div class="chart-container">
                <h2>Recent Events</h2>
                <table>
                    <tr>
                        <th>Timestamp</th>
                        <th>Event ID</th>
                        <th>Description</th>
                        <th>Computer</th>
                        <th>Severity</th>
                    </tr>
                    {recent_events_rows}
                </table>
            </div>
        </div>
    </body>
    </html>
    """
    
    # Fill in the template
    severity_distribution = {k: int(v) for k, v in df['Level'].value_counts().items()}
    top_event_ids = {int(k): int(v) for k, v in df['EventID'].value_counts().head(5).items()}

    html_content = html_content.format(
        timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        total_events=len(df),
        time_range=f"{df['Timestamp'].min()} to {df['Timestamp'].max()}",
        severity_distribution=severity_distribution,
        top_event_ids=top_event_ids,
        severity_rows=severity_rows,
        eventid_rows=eventid_rows,
        recent_events_rows=recent_events_rows
    )
    
    # Write the HTML file
    output_file = os.path.join(output_dir, "static_dashboard.html")
    try:
        with open(output_file, "w", encoding="utf-8") as f:
            f.write(html_content)
        print(f"Dashboard generated: {output_file}")
    except Exception as e:
        print(f"Error writing HTML file: {str(e)}")
        return None
    
    return output_file

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate a static HTML dashboard using a CSV file")
    parser.add_argument("--file", default="data/uploads/timeline.csv", help="Path to the CSV file")
    parser.add_argument("--output", default="data/reports", help="Directory to save the output files")
    
    args = parser.parse_args()
    dashboard_file = generate_static_dashboard(args.file, args.output)
    
    # Try to open the dashboard in the default browser
    if dashboard_file:
        try:
            print(f"Opening dashboard in browser: {dashboard_file}")
            webbrowser.open(f"file://{os.path.abspath(dashboard_file)}")
        except Exception as e:
            print(f"Could not open dashboard in browser: {str(e)}")
            print(f"Please open the dashboard manually: {dashboard_file}")