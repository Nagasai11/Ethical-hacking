import os
from datetime import datetime
import logging
from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.lib.units import inch
import io
import base64
import plotly.io as pio

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("reporter.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def generate_report(analysis_results, visualizations, output_dir):
    """
    Generate a PDF report based on the analysis results and visualizations
    
    Args:
        analysis_results (dict): Dictionary containing analysis results
        visualizations (dict): Dictionary containing visualization figures
        output_dir (str): Directory to save the report
        
    Returns:
        str: Path to the generated PDF report
    """
    try:
        # Create timestamp for the report file
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_file = os.path.join(output_dir, f"security_report_{timestamp}.pdf")
        
        logger.info(f"Generating report: {report_file}")
        
        # Create the PDF document
        doc = SimpleDocTemplate(report_file, pagesize=letter)
        styles = getSampleStyleSheet()
        
        # Create custom styles
        styles.add(ParagraphStyle(
            name='Title',
            parent=styles['Heading1'],
            fontSize=18,
            spaceAfter=12
        ))
        
        styles.add(ParagraphStyle(
            name='Heading2',
            parent=styles['Heading2'],
            fontSize=14,
            spaceAfter=10
        ))
        
        styles.add(ParagraphStyle(
            name='Normal',
            parent=styles['Normal'],
            fontSize=10,
            spaceAfter=8
        ))
        
        # Create the content
        content = []
        
        # Add title
        content.append(Paragraph("Windows Event Log Security Analysis Report", styles['Title']))
        content.append(Paragraph(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", styles['Normal']))
        content.append(Spacer(1, 0.25*inch))
        
        # Add summary section
        content.append(Paragraph("Executive Summary", styles['Heading2']))
        
        # Extract time range
        time_range = analysis_results.get('time_range', {})
        start_time = time_range.get('start', 'N/A')
        end_time = time_range.get('end', 'N/A')
        
        # Extract severity counts
        severity_distribution = analysis_results.get('severity_distribution', {})
        high_count = severity_distribution.get('high', 0)
        medium_count = severity_distribution.get('medium', 0)
        low_count = severity_distribution.get('low', 0)
        
        # Create summary text
        summary_text = f"""
        This report presents the analysis of Windows Event Logs from {start_time} to {end_time}.
        The analysis identified:
        • {high_count} high severity events
        • {medium_count} medium severity events
        • {low_count} low severity events
        """
        
        content.append(Paragraph(summary_text, styles['Normal']))
        content.append(Spacer(1, 0.25*inch))
        
        # Add potential attacks section if available
        potential_attacks = analysis_results.get('potential_attacks', [])
        if potential_attacks:
            content.append(Paragraph("Potential Security Threats Detected", styles['Heading2']))
            
            for attack in potential_attacks:
                attack_text = f"""
                <b>{attack.get('type', 'Unknown Attack Type')}</b>
                <br/>Severity: {attack.get('severity', 'Unknown')}
                <br/>Evidence: {attack.get('evidence', 'No evidence provided')}
                """
                content.append(Paragraph(attack_text, styles['Normal']))
            
            content.append(Spacer(1, 0.25*inch))
        
        # Add visualizations
        content.append(Paragraph("Visualizations", styles['Heading2']))
        
        # Add timeline visualization
        if 'timeline' in visualizations:
            content.append(Paragraph("Event Timeline", styles['Heading2']))
            timeline_img = convert_plotly_to_image(visualizations['timeline'])
            content.append(timeline_img)
            content.append(Spacer(1, 0.25*inch))
        
        # Add severity distribution visualization
        if 'severity' in visualizations:
            content.append(Paragraph("Severity Distribution", styles['Heading2']))
            severity_img = convert_plotly_to_image(visualizations['severity'])
            content.append(severity_img)
            content.append(Spacer(1, 0.25*inch))
        
        # Add hourly distribution visualization
        if 'hourly' in visualizations:
            content.append(Paragraph("Hourly Event Distribution", styles['Heading2']))
            hourly_img = convert_plotly_to_image(visualizations['hourly'])
            content.append(hourly_img)
            content.append(Spacer(1, 0.25*inch))
        
        # Add high severity events table
        content.append(Paragraph("High Severity Events", styles['Heading2']))
        high_severity_events = analysis_results.get('high_severity_events', [])
        
        if high_severity_events:
            # Create table data
            table_data = [["Timestamp", "Event ID", "Description", "Computer"]]
            
            for event in high_severity_events[:10]:  # Limit to 10 events to avoid large reports
                table_data.append([
                    event.get('Timestamp', 'N/A'),
                    str(event.get('EventID', 'N/A')),
                    event.get('Description', 'N/A'),
                    event.get('Computer', 'N/A')
                ])
            
            # Create table
            table = Table(table_data, colWidths=[1.5*inch, 0.8*inch, 2.5*inch, 1.2*inch])
            
            # Add table style
            table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.darkblue),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
            
            content.append(table)
        else:
            content.append(Paragraph("No high severity events detected.", styles['Normal']))
        
        content.append(Spacer(1, 0.25*inch))
        
        # Add recommendations section
        content.append(Paragraph("Recommendations", styles['Heading2']))
        
        recommendations_text = """
        Based on the analysis, the following actions are recommended:
        
        1. Review all high severity events and investigate any suspicious activity.
        2. Ensure that all systems are up-to-date with the latest security patches.
        3. Verify that proper access controls are in place for sensitive systems.
        4. Consider implementing additional monitoring for critical systems.
        5. Review and update security policies and procedures as needed.
        """
        
        content.append(Paragraph(recommendations_text, styles['Normal']))
        
        # Build the PDF
        doc.build(content)
        
        logger.info(f"Report generated successfully: {report_file}")
        return report_file
        
    except Exception as e:
        logger.exception(f"Error generating report: {str(e)}")
        raise

def convert_plotly_to_image(fig, width=600, height=400):
    """
    Convert a Plotly figure to a ReportLab Image
    
    Args:
        fig (plotly.graph_objects.Figure): Plotly figure to convert
        width (int): Width of the image in pixels
        height (int): Height of the image in pixels
        
    Returns:
        reportlab.platypus.Image: ReportLab Image object
    """
    try:
        # Convert Plotly figure to PNG image
        img_bytes = pio.to_image(fig, format='png', width=width, height=height)
        
        # Create a file-like object from the bytes
        img_io = io.BytesIO(img_bytes)
        
        # Create a ReportLab Image
        img = Image(img_io, width=6*inch, height=4*inch)
        
        return img
        
    except Exception as e:
        logger.exception(f"Error converting Plotly figure to image: {str(e)}")
        # Return a placeholder text instead
        return Paragraph("(Visualization could not be generated)", getSampleStyleSheet()['Normal'])
