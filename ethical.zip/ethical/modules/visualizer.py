import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
from datetime import datetime, timedelta
import logging

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("visualizer.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def create_visualizations(analysis_results):
    """
    Create visualizations based on the analysis results
    
    Args:
        analysis_results (dict): Dictionary containing analysis results
        
    Returns:
        dict: Dictionary containing visualization figures
    """
    try:
        logger.info("Creating visualizations from analysis results")
        
        visualizations = {}
        
        # Create timeline visualization
        visualizations['timeline'] = create_timeline_visualization(analysis_results)
        
        # Create severity distribution visualization
        visualizations['severity'] = create_severity_visualization(analysis_results)
        
        # Create hourly distribution visualization
        visualizations['hourly'] = create_hourly_visualization(analysis_results)
        
        # Create event ID distribution visualization
        visualizations['event_ids'] = create_event_id_visualization(analysis_results)
        
        # Create heatmap of events over time
        visualizations['heatmap'] = create_event_heatmap(analysis_results)
        
        logger.info("Visualizations created successfully")
        return visualizations
        
    except Exception as e:
        logger.exception(f"Error creating visualizations: {str(e)}")
        raise

def create_timeline_visualization(analysis_results):
    """
    Create a timeline visualization of events by severity
    
    Args:
        analysis_results (dict): Dictionary containing analysis results
        
    Returns:
        plotly.graph_objects.Figure: Timeline figure
    """
    try:
        # Extract daily events
        daily_events = analysis_results.get('daily_events', {})
        
        if not daily_events:
            # Create empty figure if no data
            fig = go.Figure()
            fig.update_layout(
                title="Event Timeline (No Data Available)",
                xaxis_title="Date",
                yaxis_title="Number of Events"
            )
            return fig
        
        # Convert to DataFrame
        df = pd.DataFrame(list(daily_events.items()), columns=['Date', 'Count'])
        df['Date'] = pd.to_datetime(df['Date'])
        df = df.sort_values('Date')
        
        # Create figure
        fig = go.Figure()
        
        # Add trace for all events
        fig.add_trace(go.Scatter(
            x=df['Date'],
            y=df['Count'],
            mode='lines+markers',
            name='All Events',
            line=dict(color='blue', width=2)
        ))
        
        # Update layout
        fig.update_layout(
            title="Event Timeline",
            xaxis_title="Date",
            yaxis_title="Number of Events",
            template="plotly_white"
        )
        
        return fig
        
    except Exception as e:
        logger.exception(f"Error creating timeline visualization: {str(e)}")
        # Return empty figure on error
        fig = go.Figure()
        fig.update_layout(title="Event Timeline (Error)")
        return fig

def create_severity_visualization(analysis_results):
    """
    Create a pie chart visualization of event severity distribution
    
    Args:
        analysis_results (dict): Dictionary containing analysis results
        
    Returns:
        plotly.graph_objects.Figure: Pie chart figure
    """
    try:
        # Extract severity distribution
        severity_distribution = analysis_results.get('severity_distribution', {})
        
        if not severity_distribution:
            # Create empty figure if no data
            fig = go.Figure()
            fig.update_layout(title="Severity Distribution (No Data Available)")
            return fig
        
        # Create labels and values
        labels = list(severity_distribution.keys())
        values = list(severity_distribution.values())
        
        # Define colors for severity levels
        colors = {
            'high': 'red',
            'medium': 'orange',
            'low': 'yellow',
            'informational': 'blue'
        }
        
        # Map colors to labels
        color_values = [colors.get(label.lower(), 'gray') for label in labels]
        
        # Create figure
        fig = go.Figure(data=[go.Pie(
            labels=labels,
            values=values,
            marker_colors=color_values,
            textinfo='label+percent',
            hole=.3
        )])
        
        # Update layout
        fig.update_layout(
            title="Event Severity Distribution",
            template="plotly_white"
        )
        
        return fig
        
    except Exception as e:
        logger.exception(f"Error creating severity visualization: {str(e)}")
        # Return empty figure on error
        fig = go.Figure()
        fig.update_layout(title="Severity Distribution (Error)")
        return fig

def create_hourly_visualization(analysis_results):
    """
    Create a bar chart visualization of hourly event distribution
    
    Args:
        analysis_results (dict): Dictionary containing analysis results
        
    Returns:
        plotly.graph_objects.Figure: Bar chart figure
    """
    try:
        # Extract hourly distribution
        hourly_distribution = analysis_results.get('hourly_distribution', {})
        
        if not hourly_distribution:
            # Create empty figure if no data
            fig = go.Figure()
            fig.update_layout(
                title="Hourly Event Distribution (No Data Available)",
                xaxis_title="Hour of Day",
                yaxis_title="Number of Events"
            )
            return fig
        
        # Create DataFrame
        hours = list(range(24))
        counts = [hourly_distribution.get(hour, 0) for hour in hours]
        
        # Create figure
        fig = go.Figure(data=[go.Bar(
            x=hours,
            y=counts,
            marker_color='darkblue'
        )])
        
        # Update layout
        fig.update_layout(
            title="Hourly Event Distribution",
            xaxis_title="Hour of Day (24-hour format)",
            yaxis_title="Number of Events",
            template="plotly_white"
        )
        
        return fig
        
    except Exception as e:
        logger.exception(f"Error creating hourly visualization: {str(e)}")
        # Return empty figure on error
        fig = go.Figure()
        fig.update_layout(title="Hourly Event Distribution (Error)")
        return fig

def create_event_id_visualization(analysis_results):
    """
    Create a bar chart visualization of top event IDs
    
    Args:
        analysis_results (dict): Dictionary containing analysis results
        
    Returns:
        plotly.graph_objects.Figure: Bar chart figure
    """
    try:
        # Extract top event IDs
        top_event_ids = analysis_results.get('top_event_ids', {})
        
        if not top_event_ids:
            # Create empty figure if no data
            fig = go.Figure()
            fig.update_layout(
                title="Top Event IDs (No Data Available)",
                xaxis_title="Event ID",
                yaxis_title="Count"
            )
            return fig
        
        # Sort by count
        sorted_event_ids = dict(sorted(top_event_ids.items(), key=lambda item: item[1], reverse=True))
        
        # Create figure
        fig = go.Figure(data=[go.Bar(
            x=list(sorted_event_ids.keys()),
            y=list(sorted_event_ids.values()),
            marker_color='darkgreen'
        )])
        
        # Update layout
        fig.update_layout(
            title="Top Event IDs",
            xaxis_title="Event ID",
            yaxis_title="Count",
            template="plotly_white"
        )
        
        return fig
        
    except Exception as e:
        logger.exception(f"Error creating event ID visualization: {str(e)}")
        # Return empty figure on error
        fig = go.Figure()
        fig.update_layout(title="Top Event IDs (Error)")
        return fig

def create_event_heatmap(analysis_results):
    """
    Create a heatmap visualization of events over time
    
    Args:
        analysis_results (dict): Dictionary containing analysis results
        
    Returns:
        plotly.graph_objects.Figure: Heatmap figure
    """
    try:
        # For a proper heatmap, we would need data by day and hour
        # Since we don't have that in our analysis_results, we'll create a simulated heatmap
        
        # Create a date range for the last 7 days
        end_date = datetime.now()
        start_date = end_date - timedelta(days=7)
        dates = [start_date + timedelta(days=i) for i in range(8)]
        
        # Create hours
        hours = list(range(24))
        
        # Create a random matrix of values
        import numpy as np
        z = np.random.randint(0, 10, size=(len(dates), len(hours)))
        
        # Create x and y labels
        x = [f"{hour:02d}:00" for hour in hours]
        y = [date.strftime("%Y-%m-%d") for date in dates]
        
        # Create figure
        fig = go.Figure(data=go.Heatmap(
            z=z,
            x=x,
            y=y,
            colorscale='Viridis',
            hoverongaps=False
        ))
        
        # Update layout
        fig.update_layout(
            title="Event Heatmap (Hour of Day vs Date)",
            xaxis_title="Hour of Day",
            yaxis_title="Date",
            template="plotly_white"
        )
        
        return fig
        
    except Exception as e:
        logger.exception(f"Error creating event heatmap: {str(e)}")
        # Return empty figure on error
        fig = go.Figure()
        fig.update_layout(title="Event Heatmap (Error)")
        return fig
