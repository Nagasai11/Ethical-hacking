import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.application import MIMEApplication
import logging
from datetime import datetime

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("notifier.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def send_email_notification(report_file, recipients, smtp_server, smtp_port, 
                           smtp_username, smtp_password, sender_email, 
                           use_tls=True, high_severity_count=0):
    """
    Send an email notification with the PDF report attached
    
    Args:
        report_file (str): Path to the PDF report file
        recipients (list): List of email recipients
        smtp_server (str): SMTP server address
        smtp_port (int): SMTP server port
        smtp_username (str): SMTP username
        smtp_password (str): SMTP password
        sender_email (str): Sender email address
        use_tls (bool): Whether to use TLS for the SMTP connection
        high_severity_count (int): Number of high severity events detected
        
    Returns:
        bool: True if the email was sent successfully, False otherwise
    """
    try:
        logger.info(f"Preparing to send email notification to {recipients}")
        
        # Create the email message
        msg = MIMEMultipart()
        msg['From'] = sender_email
        msg['To'] = ', '.join(recipients)
        
        # Set the subject based on severity
        if high_severity_count > 0:
            msg['Subject'] = f"ALERT: {high_severity_count} High Severity Security Events Detected"
        else:
            msg['Subject'] = "Security Analysis Report"
        
        # Add the email body
        body = f"""
        <html>
        <body>
            <h2>Windows Event Log Security Analysis Report</h2>
            <p>Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
            
            <p>The automated security analysis has completed. Please find the detailed report attached.</p>
            
            <p><strong>Summary:</strong></p>
            <ul>
                <li>{high_severity_count} high severity events detected</li>
            </ul>
            
            <p>Please review the attached report for detailed information and recommendations.</p>
            
            <p>This is an automated message. Please do not reply to this email.</p>
        </body>
        </html>
        """
        
        msg.attach(MIMEText(body, 'html'))
        
        # Attach the PDF report
        with open(report_file, 'rb') as f:
            attachment = MIMEApplication(f.read(), _subtype='pdf')
            attachment.add_header('Content-Disposition', 'attachment', 
                                 filename=os.path.basename(report_file))
            msg.attach(attachment)
        
        # Connect to the SMTP server and send the email
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            if use_tls:
                server.starttls()
            
            if smtp_username and smtp_password:
                server.login(smtp_username, smtp_password)
            
            server.send_message(msg)
        
        logger.info(f"Email notification sent successfully to {recipients}")
        return True
        
    except Exception as e:
        logger.exception(f"Error sending email notification: {str(e)}")
        return False

def send_email_with_flask_mail(report_file, recipients, mail_instance, high_severity_count=0):
    """
    Send an email notification with the PDF report attached using Flask-Mail
    
    Args:
        report_file (str): Path to the PDF report file
        recipients (list): List of email recipients
        mail_instance: Flask-Mail instance
        high_severity_count (int): Number of high severity events detected
        
    Returns:
        bool: True if the email was sent successfully, False otherwise
    """
    try:
        from flask_mail import Message
        
        logger.info(f"Preparing to send email notification using Flask-Mail to {recipients}")
        
        # Set the subject based on severity
        if high_severity_count > 0:
            subject = f"ALERT: {high_severity_count} High Severity Security Events Detected"
        else:
            subject = "Security Analysis Report"
        
        # Create the email body
        body = f"""
        <html>
        <body>
            <h2>Windows Event Log Security Analysis Report</h2>
            <p>Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
            
            <p>The automated security analysis has completed. Please find the detailed report attached.</p>
            
            <p><strong>Summary:</strong></p>
            <ul>
                <li>{high_severity_count} high severity events detected</li>
            </ul>
            
            <p>Please review the attached report for detailed information and recommendations.</p>
            
            <p>This is an automated message. Please do not reply to this email.</p>
        </body>
        </html>
        """
        
        # Create the message
        msg = Message(
            subject=subject,
            recipients=recipients,
            html=body
        )
        
        # Attach the PDF report
        with open(report_file, 'rb') as f:
            msg.attach(
                filename=os.path.basename(report_file),
                content_type='application/pdf',
                data=f.read()
            )
        
        # Send the message
        mail_instance.send(msg)
        
        logger.info(f"Email notification sent successfully using Flask-Mail to {recipients}")
        return True
        
    except Exception as e:
        logger.exception(f"Error sending email notification with Flask-Mail: {str(e)}")
        return False
