import os
import subprocess
import pandas as pd
import logging
import json
from datetime import datetime
from config import Config

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("parser.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def parse_logs(evtx_files, hayabusa_path, sigma_rules_path, output_dir):
    """
    Parse Windows Event Log (EVTX) files using Hayabusa
    
    Args:
        evtx_files (list): List of paths to EVTX files
        hayabusa_path (str): Path to Hayabusa executable
        sigma_rules_path (str): Path to Sigma rules directory
        output_dir (str): Directory to save output CSV
        
    Returns:
        str: Path to the generated CSV file
    """
    try:
        # Create timestamp for the output file
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = os.path.join(output_dir, f"hayabusa_output_{timestamp}.csv")
        
        # Prepare the command
        cmd = [
            hayabusa_path,
            "csv-timeline",
            "-d", ",".join(evtx_files),  # Directory or files to parse
            "-r", sigma_rules_path,      # Rules directory
            "-o", output_file,           # Output file
            "--level", "high,medium,low" # Include all severity levels
        ]
        
        logger.info(f"Running Hayabusa with command: {' '.join(cmd)}")
        
        # Execute Hayabusa
        process = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        
        stdout, stderr = process.communicate()
        
        if process.returncode != 0:
            logger.error(f"Hayabusa failed with error: {stderr}")
            raise Exception(f"Hayabusa execution failed: {stderr}")
        
        logger.info(f"Hayabusa execution completed successfully. Output saved to {output_file}")
        logger.debug(f"Hayabusa output: {stdout}")
        
        # Verify the output file exists
        if not os.path.exists(output_file):
            logger.error(f"Output file {output_file} was not created")
            raise FileNotFoundError(f"Expected output file {output_file} not found")
        
        return output_file
        
    except Exception as e:
        logger.exception(f"Error parsing logs: {str(e)}")
        raise

def read_csv_to_dataframe(csv_file):
    """
    Read the Hayabusa CSV output into a pandas DataFrame
    
    Args:
        csv_file (str): Path to the CSV file
        
    Returns:
        pandas.DataFrame: DataFrame containing the parsed logs
    """
    try:
        logger.info(f"Reading CSV file: {csv_file}")
        df = pd.read_csv(csv_file)
        logger.info(f"Successfully read {len(df)} rows from {csv_file}")
        
        # Map columns to expected format if needed
        column_mapping = {
            'Timestamp': 'Timestamp',
            'RuleTitle': 'Description',  # Use RuleTitle as Description if Description doesn't exist
            'Level': 'Level',
            'Computer': 'Computer',
            'Channel': 'Channel',
            'EventID': 'EventID'
        }
        
        # Check if we need to rename columns
        rename_dict = {}
        for expected_col, actual_col in column_mapping.items():
            if expected_col in df.columns and expected_col != actual_col:
                rename_dict[expected_col] = actual_col
        
        # If Description column doesn't exist but RuleTitle does, use RuleTitle
        if 'Description' not in df.columns and 'RuleTitle' in df.columns:
            rename_dict['RuleTitle'] = 'Description'
        
        # Rename columns if needed
        if rename_dict:
            df = df.rename(columns=rename_dict)
        
        # Ensure required columns exist
        required_columns = ['Timestamp', 'EventID', 'Level']
        missing_columns = [col for col in required_columns if col not in df.columns]
        
        if missing_columns:
            logger.warning(f"Missing required columns in CSV: {missing_columns}")
            
            # Add missing columns with default values
            for col in missing_columns:
                if col == 'Level':
                    df['Level'] = 'medium'  # Default severity
                elif col == 'EventID':
                    df['EventID'] = 0  # Default EventID
                elif col == 'Timestamp':
                    df['Timestamp'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")  # Default timestamp
        
        # Add Description column if it doesn't exist
        if 'Description' not in df.columns:
            if 'Details' in df.columns:
                df['Description'] = df['Details']
            else:
                df['Description'] = "No description available"
        
        return df
    except Exception as e:
        logger.exception(f"Error reading CSV file: {str(e)}")
        raise

# For testing/simulation purposes
def simulate_parsed_data():
    """
    Generate simulated data for testing when Hayabusa is not available
    
    Returns:
        pandas.DataFrame: DataFrame containing simulated log data
    """
    import numpy as np
    from datetime import datetime, timedelta
    
    # Create a date range for the last 7 days
    end_date = datetime.now()
    start_date = end_date - timedelta(days=7)
    dates = [start_date + timedelta(hours=i) for i in range(int((end_date - start_date).total_seconds() / 3600))]
    
    # Event IDs commonly found in Windows logs
    event_ids = [4624, 4625, 4634, 4648, 4672, 4688, 4720, 4724, 4728, 5140, 7045]
    
    # Severity levels
    severity_levels = ['high', 'medium', 'low']
    severity_weights = [0.2, 0.3, 0.5]  # Probability weights
    
    # Create random data
    data = {
        'Timestamp': [d.strftime("%Y-%m-%d %H:%M:%S") for d in dates],
        'EventID': np.random.choice(event_ids, size=len(dates)),
        'Computer': ['DESKTOP-' + ''.join(np.random.choice(list('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'), size=6)) for _ in range(len(dates))],
        'Channel': ['Security' for _ in range(len(dates))],
        'Level': np.random.choice(severity_levels, size=len(dates), p=severity_weights),
        'Description': ['Simulated event for testing' for _ in range(len(dates))]
    }
    
    # Create DataFrame
    df = pd.DataFrame(data)
    
    # Add some specific high-severity events
    high_events = [
        {'Timestamp': (end_date - timedelta(hours=12)).strftime("%Y-%m-%d %H:%M:%S"), 
         'EventID': 4625, 
         'Computer': 'DESKTOP-SERVER1', 
         'Channel': 'Security', 
         'Level': 'high', 
         'Description': 'Failed login attempt from suspicious IP'},
        {'Timestamp': (end_date - timedelta(hours=8)).strftime("%Y-%m-%d %H:%M:%S"), 
         'EventID': 4672, 
         'Computer': 'DESKTOP-SERVER1', 
         'Channel': 'Security', 
         'Level': 'high', 
         'Description': 'Special privileges assigned to new logon'},
        {'Timestamp': (end_date - timedelta(hours=4)).strftime("%Y-%m-%d %H:%M:%S"), 
         'EventID': 7045, 
         'Computer': 'DESKTOP-SERVER1', 
         'Channel': 'System', 
         'Level': 'high', 
         'Description': 'New service was installed: suspicious.exe'}
    ]
    
    # Append high severity events
    for event in high_events:
        df = pd.concat([df, pd.DataFrame([event])], ignore_index=True)
    
    # Sort by timestamp
    df['Timestamp'] = pd.to_datetime(df['Timestamp'])
    df = df.sort_values('Timestamp').reset_index(drop=True)
    
    return df
