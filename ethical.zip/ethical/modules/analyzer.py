import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import logging

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("analyzer.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def analyze_data(df):
    """
    Analyze the parsed log data to extract insights
    
    Args:
        df (pandas.DataFrame): DataFrame containing the parsed logs
        
    Returns:
        dict: Dictionary containing analysis results
    """
    try:
        logger.info(f"Starting analysis of {len(df)} log entries")
        
        # Ensure timestamp is in datetime format
        if 'Timestamp' in df.columns and not pd.api.types.is_datetime64_any_dtype(df['Timestamp']):
            df['Timestamp'] = pd.to_datetime(df['Timestamp'])
        
        # Group events by severity
        severity_counts = df['Level'].value_counts().to_dict()
        logger.info(f"Severity distribution: {severity_counts}")
        
        # Extract high severity events
        high_severity_events = df[df['Level'] == 'high'].copy()
        logger.info(f"Found {len(high_severity_events)} high severity events")
        
        # Time-based analysis
        df['Hour'] = df['Timestamp'].dt.hour
        hourly_distribution = df.groupby('Hour').size().to_dict()
        
        # Get events by day
        df['Date'] = df['Timestamp'].dt.date
        daily_events = df.groupby('Date').size().to_dict()
        daily_events = {str(k): v for k, v in daily_events.items()}  # Convert dates to strings
        
        # Get top event IDs
        top_event_ids = df['EventID'].value_counts().head(10).to_dict()
        
        # Calculate time range of the data
        time_range = {
            'start': df['Timestamp'].min().strftime('%Y-%m-%d %H:%M:%S'),
            'end': df['Timestamp'].max().strftime('%Y-%m-%d %H:%M:%S')
        }
        
        # Identify potential attack patterns
        # For example, multiple failed login attempts
        potential_attacks = identify_attack_patterns(df)
        
        # Prepare analysis results
        analysis_results = {
            'severity_distribution': severity_counts,
            'high_severity_events': high_severity_events.to_dict('records'),
            'hourly_distribution': hourly_distribution,
            'daily_events': daily_events,
            'top_event_ids': top_event_ids,
            'time_range': time_range,
            'potential_attacks': potential_attacks
        }
        
        logger.info("Analysis completed successfully")
        return analysis_results
        
    except Exception as e:
        logger.exception(f"Error analyzing data: {str(e)}")
        raise

def identify_attack_patterns(df):
    """
    Identify potential attack patterns in the log data
    
    Args:
        df (pandas.DataFrame): DataFrame containing the parsed logs
        
    Returns:
        list: List of potential attack patterns identified
    """
    patterns = []
    
    try:
        # Check for multiple failed login attempts (Event ID 4625)
        if 'EventID' in df.columns:
            failed_logins = df[df['EventID'] == 4625].copy()
            
            if len(failed_logins) > 0:
                # Group by source IP or username if available
                # For simplicity, we'll just check the count
                if len(failed_logins) >= 5:
                    patterns.append({
                        'type': 'Potential Brute Force Attack',
                        'evidence': f'Found {len(failed_logins)} failed login attempts',
                        'severity': 'high'
                    })
        
        # Check for privilege escalation (Event ID 4672)
        privilege_escalations = df[df['EventID'] == 4672].copy() if 'EventID' in df.columns else pd.DataFrame()
        if len(privilege_escalations) > 0:
            patterns.append({
                'type': 'Privilege Escalation',
                'evidence': f'Found {len(privilege_escalations)} privilege escalation events',
                'severity': 'high'
            })
        
        # Check for new service installations (Event ID 7045)
        new_services = df[df['EventID'] == 7045].copy() if 'EventID' in df.columns else pd.DataFrame()
        if len(new_services) > 0:
            patterns.append({
                'type': 'New Service Installation',
                'evidence': f'Found {len(new_services)} new service installation events',
                'severity': 'medium'
            })
        
        # Add more pattern detection logic here
        
        return patterns
        
    except Exception as e:
        logger.exception(f"Error identifying attack patterns: {str(e)}")
        return []

def get_critical_events(analysis_results):
    """
    Extract critical events from the analysis results
    
    Args:
        analysis_results (dict): Dictionary containing analysis results
        
    Returns:
        list: List of critical events
    """
    critical_events = []
    
    # Add high severity events
    if 'high_severity_events' in analysis_results:
        critical_events.extend(analysis_results['high_severity_events'])
    
    # Add potential attacks
    if 'potential_attacks' in analysis_results:
        for attack in analysis_results['potential_attacks']:
            critical_events.append({
                'Timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'EventID': 'N/A',
                'Computer': 'Analysis Engine',
                'Channel': 'Analysis',
                'Level': attack['severity'],
                'Description': f"{attack['type']}: {attack['evidence']}"
            })
    
    return critical_events
