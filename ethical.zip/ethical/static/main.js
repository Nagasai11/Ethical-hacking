// Main JavaScript for Automated Threat Analysis and Visualization Tool

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // File upload validation
    const fileInput = document.getElementById('evtxFiles');
    if (fileInput) {
        fileInput.addEventListener('change', function() {
            validateFiles(this.files);
        });
    }

    // Analysis button functionality
    const runAnalysisBtn = document.getElementById('runAnalysis');
    if (runAnalysisBtn) {
        runAnalysisBtn.addEventListener('click', function() {
            runAnalysis();
        });
    }

    // Report generation button
    const generateReportBtn = document.getElementById('generateReport');
    if (generateReportBtn) {
        generateReportBtn.addEventListener('click', function() {
            generateReport();
        });
    }

    // Email alert button
    const sendEmailBtn = document.getElementById('sendEmail');
    if (sendEmailBtn) {
        sendEmailBtn.addEventListener('click', function() {
            sendEmailAlert();
        });
    }

    // Initialize charts if they exist on the page
    if (document.getElementById('timelineChart')) {
        createTimelineChart();
    }

    if (document.getElementById('severityChart')) {
        createSeverityChart();
    }

    if (document.getElementById('hourlyChart')) {
        createHourlyChart();
    }
});

// File validation function
function validateFiles(files) {
    let validFiles = 0;
    let invalidFiles = [];

    for (let i = 0; i < files.length; i++) {
        if (files[i].name.toLowerCase().endsWith('.evtx')) {
            validFiles++;
        } else {
            invalidFiles.push(files[i].name);
        }
    }

    if (invalidFiles.length > 0) {
        alert('The following files are not valid EVTX files:\n' + invalidFiles.join('\n') + '\n\nPlease select only .evtx files.');
        return false;
    }

    return true;
}

// Simulated analysis function
function runAnalysis() {
    // Show loading indicator
    document.body.classList.add('loading');
    
    // Update status
    document.getElementById('lastAnalysis').textContent = new Date().toLocaleString();
    
    // Simulate API call
    setTimeout(function() {
        // Hide loading indicator
        document.body.classList.remove('loading');
        
        // Update metrics
        document.getElementById('filesProcessed').textContent = '3';
        document.getElementById('highSeverity').textContent = '18';
        
        // Show success message
        alert('Analysis completed successfully!');
        
        // Refresh charts with new data
        updateCharts();
    }, 3000);
}

// Simulated report generation
function generateReport() {
    alert('Generating PDF report...');
    
    // Simulate report generation
    setTimeout(function() {
        alert('Report generated successfully! Saved to data/reports/');
    }, 2000);
}

// Simulated email alert
function sendEmailAlert() {
    alert('Sending email alert to administrators...');
    
    // Simulate email sending
    setTimeout(function() {
        alert('Email alert sent successfully!');
    }, 1500);
}

// Create timeline chart
function createTimelineChart() {
    // Sample data for timeline chart
    const timelineData = {
        x: ['2023-01-01', '2023-01-02', '2023-01-03', '2023-01-04', '2023-01-05'],
        y: [5, 10, 3, 7, 4],
        type: 'scatter',
        mode: 'lines+markers',
        name: 'High Severity',
        line: {
            color: 'red',
            width: 2
        }
    };

    const timelineData2 = {
        x: ['2023-01-01', '2023-01-02', '2023-01-03', '2023-01-04', '2023-01-05'],
        y: [15, 12, 8, 9, 11],
        type: 'scatter',
        mode: 'lines+markers',
        name: 'Medium Severity',
        line: {
            color: 'orange',
            width: 2
        }
    };

    const timelineData3 = {
        x: ['2023-01-01', '2023-01-02', '2023-01-03', '2023-01-04', '2023-01-05'],
        y: [20, 18, 22, 15, 19],
        type: 'scatter',
        mode: 'lines+markers',
        name: 'Low Severity',
        line: {
            color: 'blue',
            width: 2
        }
    };

    // Create timeline chart
    Plotly.newPlot('timelineChart', [timelineData, timelineData2, timelineData3], {
        margin: { t: 10, r: 10, b: 40, l: 40 },
        xaxis: { title: 'Date' },
        yaxis: { title: 'Number of Events' },
        legend: { orientation: 'h', y: -0.2 }
    });
}

// Create severity distribution chart
function createSeverityChart() {
    // Sample data for severity chart
    const severityData = [{
        values: [18, 35, 47],
        labels: ['High', 'Medium', 'Low'],
        type: 'pie',
        marker: {
            colors: ['#dc3545', '#ffc107', '#17a2b8']
        },
        textinfo: 'label+percent',
        hole: 0.4
    }];

    // Create severity chart
    Plotly.newPlot('severityChart', severityData, {
        margin: { t: 10, r: 10, b: 10, l: 10 },
        showlegend: false
    });
}

// Create hourly distribution chart
function createHourlyChart() {
    // Sample data for hourly distribution
    const hours = Array.from(Array(24).keys());
    const counts = [5, 3, 2, 1, 0, 0, 2, 8, 15, 20, 18, 12, 10, 14, 16, 19, 22, 25, 18, 12, 8, 5, 3, 2];
    
    const hourlyData = [{
        x: hours,
        y: counts,
        type: 'bar',
        marker: {
            color: '#007bff'
        }
    }];
    
    // Create hourly chart
    Plotly.newPlot('hourlyChart', hourlyData, {
        margin: { t: 10, r: 10, b: 40, l: 40 },
        xaxis: { 
            title: 'Hour of Day',
            tickvals: hours,
            ticktext: hours.map(h => h.toString().padStart(2, '0') + ':00')
        },
        yaxis: { title: 'Number of Events' }
    });
}

// Update charts with new data (simulated)
function updateCharts() {
    // Update timeline chart with new random data
    const dates = ['2023-01-01', '2023-01-02', '2023-01-03', '2023-01-04', '2023-01-05'];
    const newHighData = dates.map(() => Math.floor(Math.random() * 15) + 1);
    const newMediumData = dates.map(() => Math.floor(Math.random() * 20) + 10);
    const newLowData = dates.map(() => Math.floor(Math.random() * 25) + 15);
    
    Plotly.update('timelineChart', {
        'y': [newHighData, newMediumData, newLowData]
    }, {}, [0, 1, 2]);
    
    // Update severity chart
    const highCount = Math.floor(Math.random() * 20) + 10;
    const mediumCount = Math.floor(Math.random() * 30) + 20;
    const lowCount = Math.floor(Math.random() * 40) + 30;
    
    Plotly.update('severityChart', {
        'values': [[highCount, mediumCount, lowCount]]
    }, {}, [0]);
    
    // Update table values
    const highSeverityElements = document.querySelectorAll('.badge.bg-danger');
    if (highSeverityElements.length > 0) {
        highSeverityElements[0].textContent = highCount;
    }
    
    const mediumSeverityElements = document.querySelectorAll('.badge.bg-warning.text-dark');
    if (mediumSeverityElements.length > 0) {
        mediumSeverityElements[0].textContent = mediumCount;
    }
    
    const lowSeverityElements = document.querySelectorAll('.badge.bg-info.text-dark');
    if (lowSeverityElements.length > 0) {
        lowSeverityElements[0].textContent = lowCount;
    }
}
